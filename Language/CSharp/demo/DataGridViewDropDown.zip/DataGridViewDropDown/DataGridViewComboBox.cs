using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
	/// <summary>
	/// ������ʽΪDataGridView��ComboBox
	/// </summary>
	public partial class DataGridViewComboBox : ComboBox
	{
		private const int WM_LBUTTONDOWN = 0x201, WM_LBUTTONDBLCLK = 0x203;
		private ToolStripControlHost _DataGridViewHost;
		private ToolStripDropDown _DropDown;

		private int _IdColumn;
		/// <summary>
		/// ��0��ʼ��ָʾID���к�
		/// </summary>
		public int IdColumn
		{
			get { return this._IdColumn; }
			set { this._IdColumn = value; }
		}

		/// <summary>
		/// ��0��ʼ��ָʾ��ʾֵ���к�
		/// </summary>
		public int DisplayColumn = 0;

		private object _RealValue;
		/// <summary>
		/// ѡ��ֵ
		/// </summary>
		public object RealValue
		{
			get { return this._RealValue; }
		}

		private DataTable _DataSource;
		/// <summary>
		/// ����Դ��ΪҪ��ʾ�����ݱ�
		/// </summary>
		public new DataTable DataSource
		{
			get
			{
				return _DataSource;
			}

			set
			{
				_DataSource = value;
				this.SetDataGridViewSource(this.DataGridView, value);
			}
		}

		public DataGridViewComboBox()
		{
			this.InitializeDataGridView();
		}

		/// <summary>
		/// ������ʾ��DataGridView�ؼ�
		/// </summary>
		public DataGridView DataGridView
		{
			get
			{
				return this._DataGridViewHost.Control as DataGridView;
			}
		}

		/// <summary>
		/// DataGridView�ؼ��Ŀ���
		/// </summary>
		public int DataGridViewWidth
		{
			get
			{
				return this._DataGridViewHost.Width;
			}

			set
			{
				this._DataGridViewHost.Width = value;
			}
		}

		/// <summary>
		/// DataGridView�ؼ��ĸ߶�
		/// </summary>
		public int DataGridViewHeight
		{
			get
			{
				return this._DataGridViewHost.Height;
			}
			set
			{
				this._DataGridViewHost.Height = value;
			}
		}

		private void InitializeDataGridView()
		{
			DataGridView view = new DataGridView();
			view.BorderStyle = BorderStyle.None;
			view.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			view.AutoGenerateColumns = true;
			view.RowHeadersVisible = false;
			view.AllowUserToAddRows = false;
			view.AllowUserToDeleteRows = false;
			view.AllowUserToResizeColumns = true;
			view.AllowUserToResizeRows = false;
			view.AllowUserToOrderColumns = false;
			view.ReadOnly = true;
			view.CellMouseClick += new DataGridViewCellMouseEventHandler(this.DataGridView_CellMouseClick);
			//view.DataSourceChanged += new EventHandler(this.DataGridView_DataSourceChanged);

			this._DataGridViewHost = new ToolStripControlHost(view);
			this._DataGridViewHost.AutoSize = false;
			this._DataGridViewHost.Width = this.Width;
			this._DataGridViewHost.Height = 150;
			this._DropDown = new ToolStripDropDown();
			this._DropDown.Items.Add(this._DataGridViewHost);
		}

		private void DataGridView_CellMouseClick(Object sender, DataGridViewCellMouseEventArgs e)
		{
			DataGridView grid = this.DataGridView;
			this._RealValue = grid[this.IdColumn, e.RowIndex].Value;
			this.Items.Clear();
			this.Items.Add(grid[this.DisplayColumn, grid.CurrentCell.RowIndex].Value);
			this.Text = (string)grid[this.DisplayColumn, grid.CurrentCell.RowIndex].Value;
			this._DropDown.Close();
		}

		private void DataGridView_DataSourceChanged(object sender, EventArgs e)
		{
			DataGridView grid = sender as DataGridView;
			DataTable tb_data = grid.DataSource as DataTable;
			this.SetDataGridViewSource(grid, tb_data);
		}


		private void ShowDropDown()
		{
			if (this._DropDown != null)
			{
				//this._DataGridViewHost.Size = new Size(this._DataGridViewHost.Width, this._DataGridViewHost.Height);
				this._DropDown.Show(this, 0, this.Height);
			}
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == WM_LBUTTONDBLCLK || m.Msg == WM_LBUTTONDOWN)
			{
				ShowDropDown();
				return;
			}
			base.WndProc(ref m);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this._DropDown != null)
				{
					this._DropDown.Dispose();
					this._DropDown = null;
				}
			}
			base.Dispose(disposing);
		}

		private void SetDataGridViewSource(DataGridView grid, DataTable table)
		{
			grid.Columns.Clear();

			for (int iCol = 0; iCol < table.Columns.Count; iCol++)
			{
				DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn();
				col.HeaderText = table.Columns[iCol].ColumnName;
				grid.Columns.Add(col);
			}

			for (int iRow = 0; iRow < table.Rows.Count; iRow++)
			{
				object[] values = new object[table.Columns.Count];
				for (int iCol = 0; iCol < table.Columns.Count; iCol++)
					values[iCol] = table.Rows[iRow][iCol];
				grid.Rows.Add(values);
			}
		}

	}
}
