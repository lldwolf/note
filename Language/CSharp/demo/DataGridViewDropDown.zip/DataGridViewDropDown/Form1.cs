﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private TextBox textBox1;

		private void button1_Click(object sender, EventArgs e)
		{
			//创建数据源
			DataTable tb_data = new DataTable();
			tb_data.Columns.Add("名称");
			tb_data.Columns.Add("数量");

			tb_data.Rows.Add(new string[] {"硬盘", "100" });
			tb_data.Rows.Add(new string[] { "CPU", "70" });
			tb_data.Rows.Add(new string[] { "光驱", "50" });
			tb_data.Rows.Add(new string[] { "主板", "50" });
			tb_data.Rows.Add(new string[] { "显示器", "60" });
			tb_data.Rows.Add(new string[] { "机箱", "60" });
			

			DataGridViewComboBox cmb = new DataGridViewComboBox();
			cmb.Parent = this;
			this.Controls.Add(cmb);
			cmb.Location = new Point(10, 10);
			cmb.Width = 100;
			cmb.DataSource = tb_data;		//设定数据源
			cmb.DataGridView.ColumnHeadersVisible = false;	//不显示标题行
			cmb.DataGridView.Columns[0].Width = 90;
			cmb.DataGridView.Columns[1].Width = 90;
			cmb.DataGridView.Width = 200;
			cmb.DataGridView.Height = 100;
			cmb.DataGridView.GridColor = Color.White;		//不显示表格线
			cmb.DisplayColumn = 0;		//设定第1列为显示列（选中后的值显示在文本框中）
			cmb.IdColumn = 1;			//设定第2列为值列（存放在RealValue中）
			cmb.SelectedIndexChanged += new EventHandler(Cmb_SelectedIndexChanged);		//选中后的处理方工式

			this.textBox1 = new TextBox();
			this.textBox1.Parent = this;
			this.Controls.Add(this.textBox1);
			this.textBox1.Location = new Point(10, 50);
		}

		private void Cmb_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.textBox1.Text = ((DataGridViewComboBox)sender).RealValue.ToString();
		}

		private void SetDataGridViewSource(DataGridView grid, DataTable table)
		{
			grid.Columns.Clear();

			for (int iCol = 0; iCol < table.Columns.Count; iCol++)
			{
				DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn();
				col.HeaderText = table.Columns[iCol].ColumnName;
				grid.Columns.Add(col);
			}

			for (int iRow = 0; iRow < table.Rows.Count; iRow++)
			{
				object[] values = new object[table.Columns.Count];
				for (int iCol = 0; iCol < table.Columns.Count; iCol++)
					values[iCol] = table.Rows[iRow][iCol];
				grid.Rows.Add(values);
			}
		}

		private void dataGridView1_DataSourceChanged(object sender, EventArgs e)
		{

		}

		
	}
}