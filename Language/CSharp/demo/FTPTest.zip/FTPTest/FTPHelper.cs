﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
namespace FTPTest
{
	public static class FTPHelper
	{
		private const int CACHE_SIZE = 10 * 1024;

		public static List<string> GetFileList(string FTPAddress, string username, string password)
		{
			List<string> files = new List<string>();

			try
			{
				//Create FTP request
				FtpWebRequest request = FtpWebRequest.Create(FTPAddress) as FtpWebRequest;

				request.Method = WebRequestMethods.Ftp.ListDirectory;
				request.Credentials = new NetworkCredential(username, password);
				request.UsePassive = true;
				request.UseBinary = true;
				request.KeepAlive = false;

				//Read the server's response
				FtpWebResponse response = request.GetResponse() as FtpWebResponse;
				Stream responseStream = response.GetResponseStream();
				StreamReader reader = new StreamReader(responseStream);

				while (!reader.EndOfStream)
				{
					files.Add(reader.ReadLine());
				}

				//Clean-up
				reader.Close();
				responseStream.Close(); //redundant
				response.Close();
			}
			catch (Exception ex)
			{
				throw new Exception("There was an error connecting to the FTP Server", ex);
			}

			return files;
		}

		public static void DownloadFile(string FTPAddress, string srcFile, string username, string password, string targetFile)
		{
			byte[] downloadedData = new byte[0];

			try
			{
				//Create FTP request
				//Note: format is ftp://server.com/file.ext
				FtpWebRequest request = FtpWebRequest.Create(FTPAddress + "/" + srcFile) as FtpWebRequest;

				//Get the file size first (for progress bar)
				request.Method = WebRequestMethods.Ftp.GetFileSize;
				request.Credentials = new NetworkCredential(username, password);
				request.UsePassive = true;
				request.UseBinary = true;
				request.KeepAlive = true; //don't close the connection

				int dataLength = (int)request.GetResponse().ContentLength;

				//Now get the actual data
				request = FtpWebRequest.Create(FTPAddress + "/" + srcFile) as FtpWebRequest;
				request.Method = WebRequestMethods.Ftp.DownloadFile;
				request.Credentials = new NetworkCredential(username, password);
				request.UsePassive = true;
				request.UseBinary = true;
				request.KeepAlive = false; //close the connection when done

				//Streams
				FtpWebResponse response = request.GetResponse() as FtpWebResponse;
				Stream reader = response.GetResponseStream();

				//Download to memory
				//Note: adjust the streams here to download directly to the hard drive
				MemoryStream memStream = new MemoryStream();
				byte[] buffer = new byte[CACHE_SIZE]; //downloads in chuncks

				while (true)
				{
					//Try to read the data
					int bytesRead = reader.Read(buffer, 0, buffer.Length);

					if (bytesRead == 0)
					{
						break;
					}
					else
					{
						//Write the downloaded data
						memStream.Write(buffer, 0, bytesRead);
					}
				}

				//Convert the downloaded stream to a byte array
				downloadedData = memStream.ToArray();

				//Clean up
				reader.Close();
				memStream.Close();
				response.Close();
			}
			catch (Exception ex)
			{
				throw new Exception("There was an error connecting to the FTP Server.", ex);
			}

			FileStream newFile = new FileStream(targetFile, FileMode.OpenOrCreate, FileAccess.Write);
			newFile.Write(downloadedData, 0, downloadedData.Length);
			newFile.Close();
		}

		public static void UploadFile(string FTPAddress, string targetFile, string username, string password, string srcFile)
		{
			byte[] uploadedData = new byte[0];

			try
			{
				//Create FTP request
				//Note: format is ftp://server.com/file.ext
				FtpWebRequest request = FtpWebRequest.Create(FTPAddress + "/" + targetFile) as FtpWebRequest;
				request.Method = WebRequestMethods.Ftp.UploadFile;
				request.Credentials = new NetworkCredential(username, password);
				request.UsePassive = true;
				request.UseBinary = true;
				request.KeepAlive = false; //close the connection when done

				FileStream stream = File.OpenRead(srcFile);
				byte[] buffer = new byte[stream.Length];
				stream.Read(buffer, 0, buffer.Length);
				stream.Close();

				Stream reqStream = request.GetRequestStream();
				reqStream.Write(buffer, 0, buffer.Length);
				reqStream.Close();
			}
			catch (Exception ex)
			{
				throw new Exception("There was an error connecting to the FTP Server.", ex);
			}
		}
	}
}
