﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace FTPTest
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.txtInfo.Text = string.Empty;
			try
			{
				List<string> fileList = FTPHelper.GetFileList(
					this.txtServer.Text + "//" + this.txtServerPath.Text,
					this.txtUserId.Text,
					this.txtPassword.Text);

				StringBuilder buf = new StringBuilder();
				foreach (string file in fileList)
				{
					buf.AppendLine(file);
				}

				this.txtInfo.Text = buf.ToString();
			}
			catch (Exception ex)
			{
				this.txtInfo.Text = "Get file list failed\r\n" + ex.ToString();
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.txtInfo.Text = string.Empty;
			try
			{
				FTPHelper.DownloadFile(
					this.txtServer.Text + "//" + this.txtServerPath.Text,
					this.txtDownloadFile.Text,
					this.txtUserId.Text,
					this.txtPassword.Text,
					this.txtUploadFile.Text);

				this.txtInfo.Text = "Download successfully.";
			}
			catch (Exception ex)
			{
				this.txtInfo.Text = "Get file list failed\r\n" + ex.ToString();
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			this.txtInfo.Text = string.Empty;
			string srcFile = this.txtUploadFile.Text;
			try
			{
				FTPHelper.UploadFile(
					this.txtServer.Text + "//" + this.txtServerPath.Text,
					Path.GetFileName(srcFile),
					this.txtUserId.Text,
					this.txtPassword.Text,
					srcFile);

				this.txtInfo.Text = "Upload successfully.";
			}
			catch (Exception ex)
			{
				this.txtInfo.Text = "Get file list failed\r\n" + ex.ToString();
			}
		}

	}
}
