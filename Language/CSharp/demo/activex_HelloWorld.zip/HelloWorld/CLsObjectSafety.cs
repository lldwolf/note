using System;

namespace HelloWorld
{
	// <summary>
	/// CLsObjectSafety ��ժҪ˵����
	/// </summary>
	public class CLsObjectSafety
	{
		public const System.Int32 INTERFACESAFE_FOR_UNTRUSTED_CALLER = 0x00000001;
		public const System.Int32 INTERFACESAFE_FOR_UNTRUSTED_DATA = 0x00000002;
	}
}
