using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.Reflection;

namespace AttributeTest
{
	/// <summary>
	/// Form1 ��ժҪ˵����
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows ������������ɵĴ���
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(24, 24);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(144, 23);
			this.button1.TabIndex = 0;
			this.button1.Text = "Assembly Attribute";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(24, 64);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(144, 23);
			this.button2.TabIndex = 1;
			this.button2.Text = "Class Attribute";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(208, 112);
			this.button3.Name = "button3";
			this.button3.TabIndex = 2;
			this.button3.Text = "button3";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		[Help("This is Class1")]
			public class Class1
		{
		}

		[Help("This is Class2", Version = "1.0")]
			public class Class2
		{
		}


		[Help("This is a do-nothing Class.")]
		public class AnyClass
		{
			//attaching Help attribute to our AnyMethod
			[Help("This is a do-nothing Method.")]
			public void AnyMethod()
			{
			}
			//attaching Help attribute to our AnyInt Field
			[Help("This is any Integer.")]
			public int AnyInt;
		}

		[Obsolete("�����Ѳ��ܼ���ʹ�ã���ʹ�������汾��")]
		public class UnusedClass
		{
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			HelpAttribute HelpAttr;

			//Querying Assembly Attributes
			String assemblyName;
			Process p = Process.GetCurrentProcess();
			assemblyName = p.ProcessName + ".exe";

			string str = "";
			Assembly a = Assembly.LoadFrom(assemblyName);

			foreach (Attribute attr in a.GetCustomAttributes(true))
			{
				HelpAttr = attr as HelpAttribute;
				if (null != HelpAttr)
				{
					str += "Description of " + assemblyName + ":\n" + HelpAttr.Description;
				}
			}
			MessageBox.Show(str);
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			Type type = typeof(AnyClass);
			HelpAttribute HelpAttr;
			string str = "";

			//Querying Class Attributes
			foreach (Attribute attr in type.GetCustomAttributes(true))
			{
				HelpAttr = attr as HelpAttribute;
				if (null != HelpAttr)
				{
					str += "Description of AnyClass:\n" + HelpAttr.Description + "\n";
				}
			}
			//Querying Class-Method Attributes  
			foreach(MethodInfo method in type.GetMethods())
			{
				foreach (Attribute attr in method.GetCustomAttributes(true))
				{
					HelpAttr = attr as HelpAttribute;
					if (null != HelpAttr)
					{
						str += "Description of " + method.Name + ":\n" + HelpAttr.Description + "\n"; 
					}
				}
			}
			//Querying Class-Field (only public) Attributes
			foreach(FieldInfo field in type.GetFields())
			{
				foreach (Attribute attr in field.GetCustomAttributes(true))
				{
					HelpAttr= attr as HelpAttribute;
					if (null != HelpAttr)
					{
						str += "Description of " + field.Name + ":\n" + HelpAttr.Description + "\n";
					}
				}
			}

			MessageBox.Show(str);
		
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			UnusedClass s = new UnusedClass();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
