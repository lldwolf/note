using System;

namespace AttributeTest
{
	[AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = false)]
	public class HelpAttribute : Attribute
	{
		public HelpAttribute(String Description_in)
		{
			this.description = Description_in;
			this.version = "No Version is defined for this class";
		}
		protected String description;
		public String Description
		{
			get 
			{
				return this.description;
			}
		}
		protected String version;
		public String Version
		{
			get 
			{
				return this.version;
			}
			//if we ever want our attribute user to set this property, 
			//we must specify set method for it 
			set 
			{
				this.version = value;
			}
		}
	}
}
