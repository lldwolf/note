﻿using System;
using System.Threading;
using ThreadCommon;

namespace TaskBindingSample
{
	class Program
	{
		private static Random randomer = new Random((int)DateTime.Now.Ticks);
		static void Main(string[] args)
		{
			Console.WriteLine(string.Format("Main Thread Id: [{0}]", Thread.CurrentThread.ManagedThreadId));

			Console.WriteLine("Testing started.");

			//run in sync mode
			SyncTest();

			//run in async mode
			AsyncTest();

			Console.WriteLine("Do something in main thread.");
			Console.Read();
		}

		private static void SyncTest()
		{
			BaseTaskBinding taskBinding = CreateTestTasks();
			taskBinding.ThreadMode = ThreadMode.CreateThread;
			taskBinding.MaxConcurenceTaskCount = 3;
			taskBinding.Run();
		}

		private static void AsyncTest()
		{
			BaseTaskBinding taskBinding = CreateTestTasks();
			taskBinding.ThreadMode = ThreadMode.Dispatcher;
			taskBinding.MaxConcurenceTaskCount = 3;
			taskBinding.Run(true);
		}

		private static BaseTaskBinding CreateTestTasks()
		{
			BaseTaskBinding taskBinding = new BaseTaskBinding();

			for (int i = 1; i <= 5; i++)
			{
				Task task = new Task(DoTask, null);
				task.TaskParam = task.TaskId;
				taskBinding.AddTask(task);
			}

			taskBinding.OneTaskCompleted += new EventHandler(taskBinding_OneTaskCompleted);
			taskBinding.RunCompleted += new EventHandler(taskBinding_RunCompleted);
			return taskBinding;
		}

		private static void taskBinding_OneTaskCompleted(object sender, EventArgs e)
		{
			Console.WriteLine(string.Format("Task {0} is done. Sleep {1} ms. Thread Id: {2}", (sender as Task).TaskId, (sender as Task).TaskResult, Thread.CurrentThread.ManagedThreadId));
		}

		private static void taskBinding_RunCompleted(object sender, EventArgs e)
		{
			Console.WriteLine("All tasks are done.");
		}

		private static object DoTask(object param)
		{
			Console.WriteLine(string.Format("Task [{0}] with ID {1} is running at {2}.", param, Thread.CurrentThread.ManagedThreadId, DateTime.Now));
			int sleepTime = randomer.Next(1000, 2000);
			Thread.Sleep(sleepTime);
			return sleepTime;
		}
	}
}
