﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading;

namespace ThreadCommon
{
	public class BaseTaskBinding
	{
		public BaseTaskBinding()
		{
			this.taskList = new List<Task>();
			this.taskQueue = new Queue<Task>();
			this.resetEvents = new Dictionary<string, ManualResetEvent>();
			this.MaxConcurenceTaskCount = int.MaxValue;
			this.ThreadMode = ThreadMode.ThreadPool;
		}

		private List<Task> taskList;
		private Queue<Task> taskQueue;
		private Dictionary<string, ManualResetEvent> resetEvents = new Dictionary<string, ManualResetEvent>();
		private static object newTaskLocker = new object();

		public ThreadMode ThreadMode { get; set; }
		public int MaxConcurenceTaskCount { get; set; }
		public List<Exception> Errors
		{
			get
			{
				List<Exception> errors = new List<Exception>();
				foreach (Task task in this.taskList)
				{
					if (task.IsFailed)
					{
						errors.Add(task.Error);
					}
				}
				return errors;
			}
		}

		public bool IsFailed
		{
			get
			{
				foreach (Task task in this.taskList)
				{
					if (task.IsFailed)
					{
						return true;
					}
				}

				return false;
			}
		}

		public string ErrorStack
		{
			get
			{
				StringBuilder buf = new StringBuilder();
				this.Errors.ForEach(item => buf.Append(item.ToString()));
				return buf.ToString();
			}
		}

		public event EventHandler RunCompleted;
		public event EventHandler OneTaskCompleted;

		public Task this[int index]
		{
			get
			{
				return this.taskList[index];
			}

			set
			{
				this.taskList[index] = value;
			}
		}

		public virtual void AddTask(Task task)
		{
			taskList.Add(task);
			taskQueue.Enqueue(task);

			if (task.TaskInvoker != null)
			{
				this.resetEvents.Add(task.TaskId, new ManualResetEvent(false));
			}
		}

		public void Run(bool isAsync = false)
		{
			Thread t = new Thread(new ThreadStart(this.RunTasks));
			t.SetApartmentState(ApartmentState.MTA);
			t.Name = "Run Binding Task";
			t.Start();

			if (!isAsync)
			{
				t.Join();
			}
		}

		private void RunTasks()
		{
			this.RunMe();
			WaitHandle.WaitAll(this.resetEvents.Values.ToArray());
			if (this.RunCompleted != null)
			{
				this.RunCompleted(this, EventArgs.Empty);
			}
		}

		private void RunMe()
		{
			int taskIndex = 0;
			int taskCount = this.taskQueue.Count;
			while (taskIndex < this.MaxConcurenceTaskCount && this.taskQueue.Count > 0)
			{
				Task task = this.DequeueTask();
				if (task != null)
				{
					this.RunTaskInThread(task);
					taskIndex++;
				}
				else
				{
					break;
				}
			}
		}

		private void RunTaskInThread(Task task)
		{
			switch (this.ThreadMode)
			{
				case ThreadMode.CreateThread:
					Thread t = new Thread(new ParameterizedThreadStart(this.RunTask));
					t.Start(task);
					break;
				case ThreadMode.Dispatcher:
					task.TaskInvoker.BeginInvoke(task.TaskParam, new AsyncCallback(this.Task_Complete), task);
					break;
				default:
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.RunTask), task);
					break;
			}
		}

		private void RunTask(object task)
		{
			Task taskObj = task as Task;
			try
			{
				taskObj.TaskResult = taskObj.TaskInvoker(taskObj.TaskParam);
			}
			catch (Exception ex)
			{
				taskObj.SetError(ex);
			}
			finally
			{
				resetEvents[taskObj.TaskId].Set();
			}

			this.AfterTaskCompleted(taskObj);
		}

		private void Task_Complete(IAsyncResult async)
		{
			Task taskObj = async.AsyncState as Task;
			AsyncResult res = async as AsyncResult;
			TaskDelegate invoker = res.AsyncDelegate as TaskDelegate;
			try
			{
				taskObj.TaskResult = invoker.EndInvoke(async);
			}
			catch (Exception ex)
			{
				taskObj.SetError(ex);
			}
			finally
			{
				this.resetEvents[taskObj.TaskId].Set();
			}

			this.AfterTaskCompleted(taskObj);
		}

		private void AfterTaskCompleted(Task task)
		{
			if (this.OneTaskCompleted != null)
			{
				this.OneTaskCompleted(task, EventArgs.Empty);
			}

			Task nextTask = this.DequeueTask();

			if (nextTask != null && nextTask.TaskInvoker != null)
			{
				this.RunTaskInThread(nextTask);
			}

		}

		private Task DequeueTask()
		{
			Task nextTask = null;

			lock (newTaskLocker)
			{
				if (this.taskQueue.Count > 0)
				{
					nextTask = this.taskQueue.Dequeue();
					while (nextTask.TaskInvoker == null)
					{
						nextTask = this.taskQueue.Dequeue();
					}
				}
			}

			return nextTask;
		}

	}
}
