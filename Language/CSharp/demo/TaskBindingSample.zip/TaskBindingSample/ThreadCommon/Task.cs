﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ThreadCommon
{
	public delegate object TaskDelegate(object param);

	public class Task
	{
		public Task(TaskDelegate invoker, object param)
		{
			this.taskId = Guid.NewGuid().ToString() + invoker.Method.Name;
			this.TaskInvoker = invoker;
			this.TaskParam = param;
			this.IsFailed = false;
		}

		private string taskId;
		public string TaskId { get { return this.taskId; } }

		public object Tag { get; set; }

		public TaskDelegate TaskInvoker;
		public object TaskParam;

		private object taskResult;
		private static object taskResultLocker = new object();
		public object TaskResult
		{
			get
			{
				lock (taskResultLocker)
				{
					return this.taskResult;
				}
			}

			set
			{
				lock (taskResultLocker)
				{
					this.taskResult = value;
				}
			}
		}

		public bool IsFailed { get; private set; }
		public Exception Error { get; private set; }
		public void SetError(Exception ex)
		{
			if (ex == null)
				return;

			this.IsFailed = true;
			this.Error = ex;
		}
	}
}
