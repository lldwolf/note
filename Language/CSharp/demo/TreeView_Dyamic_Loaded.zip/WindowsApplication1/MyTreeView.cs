using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
	public partial class MyTreeView : System.Windows.Forms.TreeView
	{
		private const int WM_VSCROLL = 0x0115;			//�������¼�
		private const int WM_MOUSEWHEEL = 0x020A;		//�������¼�
		private const int SB_ENDSCROLL = 8;				//����������־

		public MyTreeView()
		{
			InitializeComponent();
		}

		public event EventHandler VerticalScrolled;

		public MyTreeView(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == WM_VSCROLL || m.Msg == WM_MOUSEWHEEL)
			{
				if (m.WParam.ToInt32() != SB_ENDSCROLL)
				{
					VerticalScrolled(this, new EventArgs());
				}
				
			}
			base.WndProc(ref m);
		}

	}
}
