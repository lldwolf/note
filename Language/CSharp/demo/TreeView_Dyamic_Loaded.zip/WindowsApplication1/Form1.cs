﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private MyTreeView Tree;

		/// <summary>
		/// 要载入的全部内容
		/// </summary>
		private List<string> Nodes;

		/// <summary>
		/// 每次载入的行数
		/// </summary>
		private const int PageRows = 30;

		/// <summary>
		/// 总页数
		/// </summary>
		private int PageCount;

		/// <summary>
		/// 加载的页数
		/// </summary>
		private int LoadedPage = 0;

		/// <summary>
		/// 滚动树内容时触发的事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void TreeScrolled(object sender, EventArgs e)
		{
			if (this.LoadedPage == this.PageCount)
				return;

			TreeNode last_node_sc = this.GetLastNodeInScreen(this.Tree);

			if (this.Tree.Nodes.Count - last_node_sc.Index < 10)
			{
				this.LoadPage(this.LoadedPage + 1);
			}
		}


		private void Form1_Load(object sender, EventArgs e)
		{
			this.Tree = new MyTreeView();
			this.Tree.Parent = this;
			this.Controls.Add(this.Tree);
			this.Tree.Top = 10;
			this.Tree.Left = 10;
			this.Tree.Width = 150;
			this.Tree.Height = 200;
			this.Tree.VerticalScrolled += new EventHandler(this.TreeScrolled);

			this.Nodes = new List<string>();
			for (int i = 0; i < 1000; i++)
			{
				this.Nodes.Add("Node" + i.ToString().PadLeft(4));
			}
			this.PageCount = (int)Math.Ceiling(Convert.ToDouble(this.Nodes.Count) / PageRows);
			this.LoadPage(1);
		}

		/// <summary>
		/// 载入页
		/// </summary>
		/// <param name="page_no"></param>
		private void LoadPage(int page_no)
		{
			for (int i = this.LoadedPage * PageRows; i < page_no * PageRows - 1 && i < this.Nodes.Count; i++)
			{
				TreeNode node = new TreeNode();
				node.Text = this.Nodes[i];
				this.Tree.Nodes.Add(node);
			}
			this.LoadedPage = page_no;
		}

		private TreeNode GetLastNodeInScreen(TreeView tv)
		{
			TreeNode node = null;
			for (int x = tv.ClientSize.Width; x > 0; x -= 5)
			{
				int y;
				for (y = tv.ClientSize.Height; y > 0; y -= 5)
				{
					node = tv.GetNodeAt(x, y);
					if (node != null)
					{
						break;
					}
				}

				if (y > 0)
					break;
			}

			return node;
		}


	}
}