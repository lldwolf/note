﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace WindowsApplication1
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private CookieContainer _CookieContainer = new CookieContainer();

		private void button1_Click(object sender, EventArgs e)
		{
			DataTable tb_user = this.dataGridView1.DataSource as DataTable;
			//FrmProgress frm_prg = new FrmProgress();
			//frm_prg.Initialize(tb_user.Rows.Count, "正在提交...");
			//frm_prg.Show();

			for (int i = this.dataGridView1.Columns.Count - 1; i >= 2; i-- )
			{
				this.dataGridView1.Columns.RemoveAt(i);
			}

			this.dataGridView1.Columns.Add("提交结果", "提交结果");
			this.dataGridView1.CurrentCell = this.dataGridView1[0, 0];
			this.Update();

			for (int i = 0; i < this.dataGridView1.Rows.Count; i++ )
			{
				this.dataGridView1.CurrentCell = this.dataGridView1[0, i];
				this._CookieContainer = new CookieContainer();
				string user_name = this.dataGridView1[0, i].Value.ToString();
				string pwd = this.dataGridView1[1, i].Value.ToString();
				//frm_prg.ChangeInfo("正在提交用户 -- " + user_name + "...");
				//frm_prg.ChangeProgressBar(i + 1);
				this.dataGridView1[2, i].Value = "提交中...";
				this.Update();
				int submit_result = this.Submit(user_name, pwd);

				switch (submit_result)
				{
					case 0:
						this.dataGridView1[2, i].Value = "成功";
						break;
					case 1:
						this.dataGridView1[2, i].Value = "不能重复提交";
						break;
					case 2:
						this.dataGridView1[2, i].Value = "失败";
						break;
				}

				this.Update();
			}
			//frm_prg.Close();
			MessageBox.Show("OK");
		}

		private string GetCharCode(string str)
		{
			byte[] bs = Encoding.GetEncoding("gb2312").GetBytes(str);
			string str2 = string.Empty;
			for (int i = 0; i < bs.Length; i++)
			{
				str2 += "%" + Convert.ToString(bs[i], 16).ToUpper();
			}
			return str2;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="user_name"></param>
		/// <param name="password"></param>
		/// <returns>0: 成功 1: 已评分 2: 失败</returns>
		private int Submit(string user_name, string password)
		{
			string login_uri = "http://survey.xcar.com.cn/vote/xss/survey.php?sid=239430";
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create(login_uri);
			string res_data = "";

			string postData = "username=" + this.GetCharCode(user_name) + "&password=" + password;
			res_data = this.SendPostInfo(login_uri, postData, @"c:\1.htm");
			if (res_data == null || res_data == string.Empty)
				return 2;

			if (res_data.IndexOf("您已经参与过此次调查") > 0)
				return 1;

			string uri = "http://survey.xcar.com.cn/vote/xss/survey.php";
			postData = "answer[1893][0]=6816&webpage=1&sid=239430"
					 + "&next=下一页 >>";
			res_data = this.SendPostInfo(uri, postData, @"C:\2.htm");

			uri = "http://survey.xcar.com.cn/vote/xss/survey.php";
			postData = "webpage=8&sid=239430"
					 + "&answer[1926][0]=6965"
					 + "&answer[1927][0]=7319"
					 + "&answer[1928][0]=6980"
					 + "&answer[1929][0]=6988"
					 + "&answer[1930][0]=6995"
					 + "&next=下一页 >>";
			res_data = this.SendPostInfo(uri, postData, @"C:\3.htm");

			postData = "webpage=9&sid=239430"
					 + "&answer[1932][0]=7006"
					 + "&answer[1933][0]=7013"
					 + "&next=下一页 >>";
			res_data = this.SendPostInfo(uri, postData, @"C:\4.htm");

			postData = "webpage=10&sid=239430"
					 + "&answer[1934][0]=7040"
					 + "&answer[1937][0]=7217"
					 + "&whitebox="
					 + "&answer[1939][0]=7222"
					 + "&answer[1940][0]=7224"
					 + "&next=下一页 >>";
			res_data = this.SendPostInfo(uri, postData, @"C:\5.htm");

			postData = "webpage=11&sid=239430"
					 + "&answer[1942][0]=7235"
					 + "&answer[1943][0]=7241"
					 + "&answer[1944][0]=6816"
					 + "&next=下一页 >>";
			res_data = this.SendPostInfo(uri, postData, @"C:\6.htm");

			postData = "webpage=12&sid=239430"
					 + "&answer[1952][0]=7283"
					 + "&answer[1953][0]=7287"
					 + "&answer[1954][0]=7290"
					 + "&answer[1955][0]=7297"
					 + "&answer[1956][0]=7303"
					 + "&answer[1957][0]=7318"
					 + "&answer[1958][0]=25"
					 + "&answer[1958][1]=295"
					 + "&answer[1958][2]=2369"
					 + "&next=完成";
			res_data = this.SendPostInfo(uri, postData, @"C:\7.htm");

			if (res_data.IndexOf("提交成功") > 0)
				return 0;
			else
				return 2;
		}

		private string SendPostInfo(string uri, string post_data, string info_file)
		{
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create(uri);
			req.CookieContainer = this._CookieContainer;
			string res_data = "";
			req.Timeout = 100 * 1000;
			req.Method = "POST";
			string postData = post_data;
			ASCIIEncoding encoding = new ASCIIEncoding();
			byte[] byte1 = encoding.GetBytes(postData);
			req.ContentType = "application/x-www-form-urlencoded";
			req.ContentLength = postData.Length;

			HttpWebResponse res = null;
			try
			{
				res_data = "";
				Stream newStream = req.GetRequestStream();
				newStream.Write(byte1, 0, byte1.Length);
				res = (HttpWebResponse)req.GetResponse();
				Stream res_stream = res.GetResponseStream();
				newStream.Close();
				Encoding encode = System.Text.Encoding.Default;
				StreamReader readStream = new StreamReader(res_stream, encode);
				Char[] read = new Char[256];
				int count = readStream.Read(read, 0, 256);
				while (count > 0)
				{
					String str = new String(read, 0, count);
					res_data = res_data + str.Trim();
					count = readStream.Read(read, 0, 256);
				}
				res.Close();
				readStream.Close();

				if (info_file != null)
				{
					StreamWriter sw = new StreamWriter(info_file, false, Encoding.Default, 1024);
					sw.Write(res_data);
					sw.Close();
				}

				newStream = null;
				postData = null;
				req = null;
				res = null;
				GC.Collect();
			}
			catch (WebException)
			{
				req = null;
				GC.Collect();
			}

			return res_data;
		}

		private string GetResponseInfo(string uri)
		{
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://www.xcar.com.cn/bbs/logging.php?action=login");
			req.Timeout = 5 * 1000;
			req.Method = "GET";
			ASCIIEncoding encoding = new ASCIIEncoding();
			req.ContentType = "application/x-www-form-urlencoded";
			string res_data = "";

			HttpWebResponse res = null;
			try
			{
				res = (HttpWebResponse)req.GetResponse();
				Stream res_stream = res.GetResponseStream();
				Encoding encode = System.Text.Encoding.Default;
				StreamReader readStream = new StreamReader(res_stream, encode);
				Char[] read = new Char[256];
				int count = readStream.Read(read, 0, 256);
				while (count > 0)
				{
					String str = new String(read, 0, count);
					res_data = res_data + str.Trim();
					count = readStream.Read(read, 0, 256);
				}
				res.Close();
				readStream.Close();

				req = null;
				res = null;
				GC.Collect();
			}
			catch (WebException)
			{
				req = null;
				GC.Collect();
			}

			return res_data;
		}

		private void button4_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			OpenFileDialog open_dlg = new OpenFileDialog();
			open_dlg.DefaultExt = "txt";
			open_dlg.Filter = "文件文件 (*.txt)|*.txt";
			if (open_dlg.ShowDialog() != DialogResult.OK)
				return;

			this.txtFile.Text = open_dlg.FileName;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			DataTable tb_user = new DataTable();
			tb_user.Columns.Add("用户名");
			tb_user.Columns.Add("口令");
			
			StreamReader sr = new StreamReader(this.txtFile.Text, Encoding.Default);
			string user_info = sr.ReadLine();

			while (user_info != null)
			{
				string[] s1 = user_info.Split(',');
				try
				{
					DataRow new_row = tb_user.NewRow();
					new_row["用户名"] = s1[0];
					new_row["口令"] = s1[1];
					tb_user.Rows.Add(new_row);
				}
				catch
				{
				}
				user_info = sr.ReadLine();
			}

			this.dataGridView1.DataSource = tb_user;
			if (tb_user.Rows.Count > 0)
				this.btnSubmit.Enabled = true;
			else
				this.btnSubmit.Enabled = false;
		}

		

	}
}