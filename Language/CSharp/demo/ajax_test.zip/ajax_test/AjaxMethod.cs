using System;
using System.Collections;
using AjaxPro;

namespace ajax_test
{
	public class AjaxMethod
	{
		[AjaxMethod]
		public static ArrayList GetNIVNumber(string str)
		{
			ArrayList arr = new ArrayList();
			arr.Add(str.ToUpper());
			return arr;
		}
	}
}
