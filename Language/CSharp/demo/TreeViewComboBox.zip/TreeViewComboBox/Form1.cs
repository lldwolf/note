﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TreeViewComboBox
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			TreeNode root = new TreeNode("全部", 0, 0);
			root.Nodes.Add("CPU");
			root.Nodes.Add("内存");
			root.Nodes.Add("硬盘");
			root.Nodes.Add("显卡");
			ComboBoxTreeView cmb1 = new ComboBoxTreeView();
			cmb1.Parent = this;
			this.Controls.Add(cmb1);
			cmb1.Location = new Point(20, 20);
			cmb1.Width = 100;
			cmb1.TreeView.Nodes.Add(root);

			root = new TreeNode("全部", 0, 0);
			root.Nodes.Add("CPU");
			root.Nodes.Add("内存");
			root.Nodes.Add("硬盘");
			root.Nodes.Add("显卡"); ComboBoxTreeView cmb2 = new ComboBoxTreeView();
			cmb2.DropDownStyle = ComboBoxStyle.DropDownList;
			cmb2.Parent = this;
			this.Controls.Add(cmb2);
			cmb2.Location = new Point(20, 60);
			cmb2.Width = 100;
			cmb2.TreeView.Nodes.Add(root);
		}
	}
}