using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;

namespace SystemProcess
{
	/// <summary>
	/// FrmFindDll ��ժҪ˵����
	/// </summary>
	public class FrmFindDll : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtFile;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button btnFind;
		private System.Windows.Forms.TextBox txtResult;
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmFindDll()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows ������������ɵĴ���
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtFile = new System.Windows.Forms.TextBox();
			this.txtResult = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnFind = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(116, 17);
			this.label1.TabIndex = 0;
			this.label1.Text = "�����õ��ļ�ȫ·��";
			// 
			// txtFile
			// 
			this.txtFile.Location = new System.Drawing.Point(16, 32);
			this.txtFile.Name = "txtFile";
			this.txtFile.Size = new System.Drawing.Size(456, 21);
			this.txtFile.TabIndex = 1;
			this.txtFile.Text = "";
			// 
			// txtResult
			// 
			this.txtResult.Location = new System.Drawing.Point(24, 88);
			this.txtResult.Multiline = true;
			this.txtResult.Name = "txtResult";
			this.txtResult.ReadOnly = true;
			this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtResult.Size = new System.Drawing.Size(456, 192);
			this.txtResult.TabIndex = 2;
			this.txtResult.Text = "";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(66, 17);
			this.label2.TabIndex = 3;
			this.label2.Text = "���õĽ���";
			// 
			// btnFind
			// 
			this.btnFind.Location = new System.Drawing.Point(488, 32);
			this.btnFind.Name = "btnFind";
			this.btnFind.TabIndex = 4;
			this.btnFind.Text = "����(&F)";
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(488, 72);
			this.button2.Name = "button2";
			this.button2.TabIndex = 5;
			this.button2.Text = "�˳�(&E)";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// FrmFindDll
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(576, 301);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.btnFind);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtResult);
			this.Controls.Add(this.txtFile);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FrmFindDll";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "���������ļ�";
			this.ResumeLayout(false);

		}
		#endregion

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void btnFind_Click(object sender, System.EventArgs e)
		{
			string file_referenced = this.txtFile.Text.Trim().ToLower();
			Process[] processes = Process.GetProcesses();

			string str_result = "";
			int find_count = 0;

			for(int i_p = 0; i_p < processes.Length; i_p++)
			{
				Process process = processes[i_p];
				if(process.Id == 0 || process.Id == 8)
					continue;
				ProcessModuleCollection pms = process.Modules;

				for(int i_m = 0; i_m < pms.Count; i_m++)
				{
					string module_file = pms[i_m].FileName.ToLower().Trim();
					if(module_file == file_referenced)
					{
						if(str_result != "")
							str_result += "\r\n\r\n---------------------------\r\n\r\n";
						str_result += "����: " + process.ProcessName + "\r\n"
							+ "PID: " + process.Id + "\r\n"
							+ "���ļ�: " + process.MainModule.FileName;
						find_count++;
						break;
					}
				}
			}

			this.txtResult.Text = str_result;
			MessageBox.Show("���ҵ����ø��ļ��Ľ��� "  + find_count + "��");

		}
	}
}
