using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

namespace SystemProcess
{
	/// <summary>
	/// Form1 ��ժҪ˵����
	/// </summary>
	public class FrmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.StatusBarPanel statusBarPanel3;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem miMainModule;
		private System.Windows.Forms.MenuItem miModuleList;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.MenuItem miReference;
		private System.Windows.Forms.MenuItem miRefresh;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.ComponentModel.IContainer components;

		public FrmMain()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows ������������ɵĴ���
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel3 = new System.Windows.Forms.StatusBarPanel();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.miMainModule = new System.Windows.Forms.MenuItem();
			this.miModuleList = new System.Windows.Forms.MenuItem();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.miReference = new System.Windows.Forms.MenuItem();
			this.miRefresh = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel3)).BeginInit();
			this.SuspendLayout();
			// 
			// listView1
			// 
			this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2,
																						this.columnHeader3,
																						this.columnHeader4,
																						this.columnHeader5});
			this.listView1.FullRowSelect = true;
			this.listView1.HideSelection = false;
			this.listView1.Location = new System.Drawing.Point(8, 8);
			this.listView1.MultiSelect = false;
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(496, 296);
			this.listView1.TabIndex = 0;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "ӳ������";
			this.columnHeader1.Width = 98;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "PID";
			this.columnHeader2.Width = 73;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "CPU";
			this.columnHeader3.Width = 62;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "CPUʱ��";
			this.columnHeader4.Width = 90;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "�ڴ�ʹ��";
			this.columnHeader5.Width = 81;
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 311);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2,
																						  this.statusBarPanel3});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(512, 22);
			this.statusBar1.TabIndex = 5;
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.Width = 150;
			// 
			// statusBarPanel2
			// 
			this.statusBarPanel2.Width = 150;
			// 
			// statusBarPanel3
			// 
			this.statusBarPanel3.Width = 200;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.miMainModule,
																					  this.miModuleList,
																					  this.miReference,
																					  this.menuItem3,
																					  this.miRefresh});
			this.menuItem1.Text = "����(&F)";
			// 
			// miMainModule
			// 
			this.miMainModule.Index = 0;
			this.miMainModule.Text = "��ģ��(&M)";
			this.miMainModule.Click += new System.EventHandler(this.miMainModule_Click);
			// 
			// miModuleList
			// 
			this.miModuleList.Index = 1;
			this.miModuleList.Text = "ģ���б�(&L)";
			this.miModuleList.Click += new System.EventHandler(this.miModuleList_Click);
			// 
			// timer1
			// 
			this.timer1.Interval = 2000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// miReference
			// 
			this.miReference.Index = 2;
			this.miReference.Text = "�ļ�����(&F)";
			this.miReference.Click += new System.EventHandler(this.miReference_Click);
			// 
			// miRefresh
			// 
			this.miRefresh.Index = 4;
			this.miRefresh.Text = "ˢ��(&R)";
			this.miRefresh.Click += new System.EventHandler(this.miRefresh_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 3;
			this.menuItem3.Text = "-";
			// 
			// FrmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(512, 333);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.listView1);
			this.Menu = this.mainMenu1;
			this.Name = "FrmMain";
			this.Text = "���̲鿴��";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel3)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FrmMain());
		}

		private ArrayList _Processes;
		private int OrderIndex = 1;
		private bool _Ascendent = true;

		private int CompareProcess(Process p1, Process p2)
		{
			switch(OrderIndex)
			{
				case 0:
					return string.Compare(p1.ProcessName, p2.ProcessName);
				case 1:
					if(p1.Id > p2.Id)
						return 1;
					else if(p1.Id < p2.Id)
						return -1;
					else
						return 0;
				case 2:
					if(p1.UserProcessorTime > p2.UserProcessorTime)
						return 1;
					else if(p1.UserProcessorTime < p2.UserProcessorTime)
						return -1;
					else
						return 0;
				case 3:
					if(p1.TotalProcessorTime > p2.TotalProcessorTime)
						return 1;
					else if(p1.TotalProcessorTime < p2.TotalProcessorTime)
						return -1;
					else
						return 0;
				case 4:
					if(p1.WorkingSet > p2.WorkingSet)
						return 1;
					else if(p1.WorkingSet < p2.WorkingSet)
						return -1;
					else
						return 0;
				default:
					return 0;
			}
		}

		private void DisplayProcess()
		{
			for(int i = 0; i < this._Processes.Count - 1; i++)
			{
				for(int j = i + 1; j < this._Processes.Count; j++)
				{
					Process p1 = this._Processes[i] as Process;
					Process p2 = this._Processes[j] as Process;
					int cmp = this.CompareProcess(p1, p2);
					if(this._Ascendent)
					{
						if(cmp > 0)
						{
							object mid = this._Processes[j];
							this._Processes[j] = this._Processes[i];
							this._Processes[i] = mid;
						}
					}
					else
					{
						if(cmp < 0)
						{
							object mid = this._Processes[j];
							this._Processes[j] = this._Processes[i];
							this._Processes[i] = mid;
						}
					}
				}
			}

			for(int i_p = 0; i_p < this._Processes.Count; i_p++)
			{
				Process ps = this._Processes[i_p] as Process;
				ListViewItem item_root = new ListViewItem(ps.ProcessName);
				item_root.Tag = ps.Id;
				this.listView1.Items.Add(item_root);
				item_root.SubItems.Add(ps.Id.ToString());
				item_root.SubItems.Add(ps.UserProcessorTime.Seconds.ToString());
				item_root.SubItems.Add(ps.TotalProcessorTime.Hours + ":" + ps.TotalProcessorTime.Minutes.ToString().PadLeft(2, '0') + ":" + ps.TotalProcessorTime.Seconds.ToString().PadLeft(2, '0'));
				item_root.SubItems.Add(ps.WorkingSet / 1024 + " K");
			}
		}

		private void RefreshData()
		{
			int cur_pid = 0;
			if(this.listView1.SelectedItems.Count > 0)
			{
				cur_pid = Convert.ToInt32(this.listView1.SelectedItems[0].Tag);
			}

			this._Processes = new ArrayList();

			long total_memory = 0;
			this.listView1.Items.Clear();
			Process[] process = System.Diagnostics.Process.GetProcesses();
			
			for(int i_p = 0; i_p < process.Length; i_p++)
			{
				this._Processes.Add(process[i_p]);
				total_memory += process[i_p].WorkingSet;
			}


			this.DisplayProcess();
			for(int i = 0; i < this.listView1.Items.Count; i++)
			{
				int pid = Convert.ToInt32(this.listView1.Items[i].Tag);
				if(cur_pid == pid)
				{
					this.listView1.Items[i].Selected = true;
					break;
				}
			}
			this.statusBarPanel1.Text = "������: " + process.Length;
			this.statusBarPanel3.Text = "ռ���ڴ�: " + (total_memory / 1024 / 1024) + "M";
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.RefreshData();
			//this.timer1.Enabled = true;
		
		}

		private void listView1_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			this.OrderIndex = e.Column;
			this._Ascendent = !this._Ascendent;
			this.RefreshData();
			
		}

		private void miMainModule_Click(object sender, System.EventArgs e)
		{
			int pid = Convert.ToInt32(this.listView1.SelectedItems[0].Tag);
			if(pid == 0 || pid == 8)
			{
				MessageBox.Show("���ܷ��ʸý��̣�");
				return;
			}
			Process p = Process.GetProcessById(pid);
			string file_name = "";
			file_name = p.MainModule.FileName;
			MessageBox.Show(file_name);
		}

		private void miModuleList_Click(object sender, System.EventArgs e)
		{
			int pid = Convert.ToInt32(this.listView1.SelectedItems[0].Tag);
			if(pid == 0 || pid == 8)
			{
				MessageBox.Show("���ܷ��ʸý��̣�");
				return;
			}
			Process p = Process.GetProcessById(pid);
			ProcessModuleCollection pm = p.Modules;
			string file_name = "";
			for(int i = 0; i < pm.Count; i++)
			{
				file_name += pm[i].FileName + "\r\n";
			}
			
			
			FrmInputBox frm = new FrmInputBox(file_name);
			frm.ShowDialog();

		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			this.RefreshData();
		}

		private void miReference_Click(object sender, System.EventArgs e)
		{
			FrmFindDll frm = new FrmFindDll();
			frm.ShowDialog();
		}

		private void miRefresh_Click(object sender, System.EventArgs e)
		{
			this.RefreshData();
		}

	
	}
}
