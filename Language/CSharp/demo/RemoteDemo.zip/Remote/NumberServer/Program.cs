﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using RemoteNumber;

namespace NumberServer
{
	class Program
	{
		static void Main(string[] args)
		{
			TcpServerChannel channel = new TcpServerChannel(6667);
			ChannelServices.RegisterChannel(channel, false);
			RemotingConfiguration.RegisterWellKnownServiceType(typeof(NumberAdd), "NumberAdd", WellKnownObjectMode.SingleCall);
			Console.WriteLine("Press any key to exit!");
			Console.Read();
		}
	}
}
