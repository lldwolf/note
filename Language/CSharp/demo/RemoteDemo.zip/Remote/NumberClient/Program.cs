﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using RemoteNumber;

namespace NumberClient
{
	class Program
	{
		static void Main(string[] args)
		{
			ChannelServices.RegisterChannel(new TcpClientChannel(), false);
			NumberAdd obj = (NumberAdd)Activator.GetObject(typeof(NumberAdd), "tcp://localhost:6667/NumberAdd");
			if (obj == null)
			{
				Console.WriteLine("Cannot connect to server!");
				return;
			}
			else
			{
				Console.WriteLine("Input number1: ");
				int n1 = Convert.ToInt32(Console.ReadLine());
				Console.WriteLine("Input number2: ");
				int n2 = Convert.ToInt32(Console.ReadLine());
				Console.WriteLine("The result is: " +  obj.Add(n1, n2));

			}
		}
	}
}
