﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemoteNumber
{
	public class NumberAdd : System.MarshalByRefObject
	{
		public NumberAdd()
		{
			Console.WriteLine("Construct NumberAdd Object!");
		}

		~NumberAdd()
		{
			Console.WriteLine("Destroy NumberAdd Object!");
		}


		public int Add(int number1, int number2)
		{
			return number1 + number2;
		}
	}
}
