﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DataBindingTest
{
	public partial class FrmDataSetBindingTest : Form
	{
		public FrmDataSetBindingTest()
		{
			InitializeComponent();

			this.Ds = new DsPerson();

			for (int personId = 0; personId < 100; personId++)
			{
				DsPerson.PersonRow person = this.Ds.Person.NewPersonRow();
				person.PersonId = 10001 + personId;
				person.Name = TestUtility.RandomUtility.GetRandomCnName();
				person.Gender = TestUtility.RandomUtility.GetRandomCnSex();
				person.BirthDay = TestUtility.RandomUtility.GetRandomDateTime(1930, 2010);
				person.IdentityCardId = TestUtility.RandomUtility.GetRandomPIN();
				person.Education = TestUtility.RandomUtility.GetRandomCnAcademicDegree();
				this.Ds.Person.AddPersonRow(person);
			}
		}

		private DsPerson Ds;

		private void FrmDataSetBindingTest_Load(object sender, EventArgs e)
		{
			this.dataGridView1.DataBindings.Add("DataSource", this.Ds, "Person");
		}
	}
}
