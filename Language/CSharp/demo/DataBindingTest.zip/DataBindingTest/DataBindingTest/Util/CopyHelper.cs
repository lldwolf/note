using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Soap;

namespace DataBindingTest.Util
{
	public static class CopyHelper
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="src"></param>
		/// <param name="obj"></param>
		/// <param name="base_type"></param>
		public static void CopyObjectProps(object src, object obj, Type base_type)
		{
			Type src_type = src.GetType();
			Type obj_type = obj.GetType();

			List<string> src_prop_names = GetPropertyNames(src, base_type);
			List<string> obj_prop_names = GetPropertyNames(obj, base_type);

			PropertyInfo[] src_props = src_type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
			foreach (PropertyInfo src_prop in src_props)
			{
				string prop_name = src_prop.Name;
				if (!src_prop_names.Contains(prop_name) || !obj_prop_names.Contains(prop_name)
					|| !src_prop.CanWrite || src_prop.Name.ToLower() == "item")
					continue;

				object val = src.GetType().InvokeMember(prop_name, BindingFlags.GetProperty, null, src, null);
				obj.GetType().InvokeMember(prop_name, BindingFlags.SetProperty, null, obj, new object[] { val });
			} //foreach (PropertyInfo src_prop in src_props)
		}

		private static List<string> GetPropertyNames(object obj, Type base_type)
		{
			PropertyInfo[] props = base_type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
			List<string> prop_names = new List<string>();
			foreach (PropertyInfo prop in props)
			{
				if (prop.DeclaringType.Equals(base_type))
					prop_names.Add(prop.Name);
			}
			return prop_names;
		}

		public static object CloneObject(object src)
		{
			if (src == null)
				return null;

            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                MemoryStream stream = new MemoryStream();
                formatter.Serialize(stream, src);
                stream.Seek(0, SeekOrigin.Begin);
                return formatter.Deserialize(stream);
            }
            catch (Exception ex)
            {
				MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
		}


		/// <summary>
		/// Provides a method for performing a deep copy of an object.
		/// Binary Serialization is used to perform the copy.
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="source"></param>
		/// <returns></returns>
		public static T Clone<T>(T source)
		{
			if (!typeof(T).IsSerializable)
			{
				throw new ArgumentException("The type must be serializable.", "source");
			}

			if (Object.ReferenceEquals(source, null))
			{
				return default(T);
			}

			XmlSerializer formatter = new XmlSerializer(typeof(T));
			Stream stream = new MemoryStream();
			using (stream)
			{
				formatter.Serialize(stream, source);
				stream.Seek(0, SeekOrigin.Begin);
				return (T)formatter.Deserialize(stream);
			}
		}
	}
}
