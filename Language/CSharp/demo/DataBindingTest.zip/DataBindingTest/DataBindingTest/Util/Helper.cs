﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace DataBindingTest.Util
{
	public static class Helper
	{
		public static string PrintObj(object obj)
		{
			if(obj == null)
				return "null";

			StringBuilder sb = new StringBuilder();
			PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
			foreach (PropertyInfo prop in props)
			{
				if (sb.Length > 0)
				{
					sb.Append(Environment.NewLine);
				}

				sb.Append(prop.Name);
				sb.Append(": ");
				sb.Append(obj.GetType().InvokeMember(prop.Name, BindingFlags.GetProperty, null, obj, null));
			}

			return sb.ToString();
		}
	}
}
