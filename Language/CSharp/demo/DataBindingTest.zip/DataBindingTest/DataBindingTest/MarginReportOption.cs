﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace DataBindingTest
{
	[Serializable]
	internal class MarginReportOption : INotifyPropertyChanged, ICloneable
	{
		private int logoSizeScale;
		public int LogoSizeScale
		{
			get { return this.logoSizeScale; }
			set
			{
				this.logoSizeScale = value;
				this.NotifyPropertyChanged("LogoSizeScale");
			}
		}

		private bool showLogo;
		public bool ShowLogo
		{
			get { return this.showLogo; }
			set
			{
				this.showLogo = value;
				this.NotifyPropertyChanged("ShowLogo");
			}
		}

		private bool showDealBox;
		public bool ShowDealBox
		{
			get { return this.showDealBox; }
			set
			{
				this.showDealBox = value;
				Debug.WriteLine("DealBox is Changed.");
				this.NotifyPropertyChanged("ShowDealBox");
			}
		}

		private BindingList<MarginReportColorOption> colorOptions;
		public BindingList<MarginReportColorOption> ColorOptions
		{
			get { return this.colorOptions; }
			set
			{
				this.colorOptions = value;
				this.NotifyPropertyChanged("ColorOptions");
			}
		}

		//public Dictionary<string, Color> SeriesColors { get; set; }

		private static Size baseSize = new Size(48, 12);

		public Size LogoSize
		{
			get
			{
				/**0: 50%
				 * 1: 75%
				 * 2: 100%
				 * 3: 125%
				 * 4: 150%
				 * 5: 175%
				 * 6: 200%
				 * 7: 225%
				 * 8: 250%
				 * 9: 275%
				 * 10: 300%
				 **/
				double zoom = (this.LogoSizeScale + 2) * 0.25;
				return new Size((int)(baseSize.Width * zoom), (int)(baseSize.Height * zoom));
			}
		}


		public MarginReportOption()
		{
			this.colorOptions = new BindingList<MarginReportColorOption>();
			//this.SeriesColors = new Dictionary<string, Color>();
			this.ShowLogo = false;
			this.LogoSizeScale = 2;
			this.ShowDealBox = true;
		}

		public Color GetColor(string seriesName)
		{
			foreach (MarginReportColorOption colorItem in this.colorOptions)
			{
				if (colorItem.Tenor == seriesName)
				{
					return colorItem.Color;
				}
			}

			return Color.Empty;
		}

		#region INotifyPropertyChanged Members

		private void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion

		#region ICloneable Members

		public object Clone()
		{
			MarginReportOption newObj = new MarginReportOption();
			newObj.showDealBox = this.showDealBox;
			newObj.showLogo = this.showLogo;
			newObj.logoSizeScale = this.logoSizeScale;

			if (this.colorOptions == null)
				newObj.colorOptions = null;
			else
			{
				newObj.colorOptions = new BindingList<MarginReportColorOption>();
				foreach (MarginReportColorOption item in this.colorOptions)
				{
					newObj.colorOptions.Add(item.Clone() as MarginReportColorOption);
				}
			}

			return newObj;
		}

		#endregion
	}
}
