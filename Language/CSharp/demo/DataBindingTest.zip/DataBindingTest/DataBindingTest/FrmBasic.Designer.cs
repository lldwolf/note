﻿namespace DataBindingTest
{
	partial class FrmBasic
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.label1 = new System.Windows.Forms.Label();
			this.txtStringBinding = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.dtDateBinding = new System.Windows.Forms.DateTimePicker();
			this.chkBool = new System.Windows.Forms.CheckBox();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.btnSerialize = new System.Windows.Forms.Button();
			this.btnClone = new System.Windows.Forms.Button();
			this.txtPojo = new System.Windows.Forms.TextBox();
			this.flowLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this.txtStringBinding);
			this.flowLayoutPanel1.Controls.Add(this.label2);
			this.flowLayoutPanel1.Controls.Add(this.dtDateBinding);
			this.flowLayoutPanel1.Controls.Add(this.chkBool);
			this.flowLayoutPanel1.Controls.Add(this.btnRefresh);
			this.flowLayoutPanel1.Controls.Add(this.button1);
			this.flowLayoutPanel1.Controls.Add(this.btnSerialize);
			this.flowLayoutPanel1.Controls.Add(this.btnClone);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(613, 176);
			this.flowLayoutPanel1.TabIndex = 0;
			this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(3, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "String Binding";
			// 
			// txtStringBinding
			// 
			this.txtStringBinding.Location = new System.Drawing.Point(81, 3);
			this.txtStringBinding.Name = "txtStringBinding";
			this.txtStringBinding.Size = new System.Drawing.Size(169, 20);
			this.txtStringBinding.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(256, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(91, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "DateTime Binding";
			// 
			// dtDateBinding
			// 
			this.dtDateBinding.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtDateBinding.Location = new System.Drawing.Point(353, 3);
			this.dtDateBinding.Name = "dtDateBinding";
			this.dtDateBinding.Size = new System.Drawing.Size(106, 20);
			this.dtDateBinding.TabIndex = 3;
			// 
			// chkBool
			// 
			this.chkBool.AutoSize = true;
			this.chkBool.Location = new System.Drawing.Point(465, 3);
			this.chkBool.Name = "chkBool";
			this.chkBool.Size = new System.Drawing.Size(95, 17);
			this.chkBool.TabIndex = 6;
			this.chkBool.Text = "Boolean Value";
			this.chkBool.UseVisualStyleBackColor = true;
			// 
			// btnRefresh
			// 
			this.btnRefresh.Location = new System.Drawing.Point(3, 29);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(75, 23);
			this.btnRefresh.TabIndex = 4;
			this.btnRefresh.Text = "To POJO";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new System.EventHandler(this.button1_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(84, 29);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 5;
			this.button1.Text = "To GUI";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click_1);
			// 
			// btnSerialize
			// 
			this.btnSerialize.Location = new System.Drawing.Point(165, 29);
			this.btnSerialize.Name = "btnSerialize";
			this.btnSerialize.Size = new System.Drawing.Size(75, 23);
			this.btnSerialize.TabIndex = 7;
			this.btnSerialize.Text = "Serialize";
			this.btnSerialize.UseVisualStyleBackColor = true;
			this.btnSerialize.Click += new System.EventHandler(this.btnSerialize_Click);
			// 
			// btnClone
			// 
			this.btnClone.Location = new System.Drawing.Point(246, 29);
			this.btnClone.Name = "btnClone";
			this.btnClone.Size = new System.Drawing.Size(75, 23);
			this.btnClone.TabIndex = 8;
			this.btnClone.Text = "Clone";
			this.btnClone.UseVisualStyleBackColor = true;
			this.btnClone.Click += new System.EventHandler(this.btnClone_Click);
			// 
			// txtPojo
			// 
			this.txtPojo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtPojo.Location = new System.Drawing.Point(0, 176);
			this.txtPojo.Multiline = true;
			this.txtPojo.Name = "txtPojo";
			this.txtPojo.Size = new System.Drawing.Size(613, 300);
			this.txtPojo.TabIndex = 1;
			this.txtPojo.TextChanged += new System.EventHandler(this.txtPojo_TextChanged);
			// 
			// FrmConverter
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(613, 476);
			this.Controls.Add(this.txtPojo);
			this.Controls.Add(this.flowLayoutPanel1);
			this.Name = "FrmConverter";
			this.Text = "FrmConverter";
			this.Load += new System.EventHandler(this.FrmConverter_Load);
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtStringBinding;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.DateTimePicker dtDateBinding;
		private System.Windows.Forms.Button btnRefresh;
		private System.Windows.Forms.TextBox txtPojo;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.CheckBox chkBool;
		private System.Windows.Forms.Button btnSerialize;
		private System.Windows.Forms.Button btnClone;
	}
}