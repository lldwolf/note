﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using System.Globalization;
using DataBindingTest.Model;
using DataBindingTest.Util;

namespace DataBindingTest
{
	public partial class FrmConverter : Form
	{
		public FrmConverter()
		{
			InitializeComponent();
			this.bindingPojo = new BindingPojoConvertTest();
			this.bindingPojo.PropertyChanged += new PropertyChangedEventHandler(this.BindingPojo_PropertyChanged);
		}

		private BindingPojoConvertTest bindingPojo;

		private void FrmBasicBinding_Load(object sender, EventArgs e)
		{
			this.bindingPojo.PropertyChanged += new PropertyChangedEventHandler(BindingPojoConvertTest_PropertyChanged);

			this.txtInt.DataBindings.Add("Text", this.bindingPojo, "IntValue", true, DataSourceUpdateMode.OnPropertyChanged, null, null, new NumberFormatInfo());
			this.txtRange.DataBindings.Add("Text", this.bindingPojo, "IntRange", true, DataSourceUpdateMode.OnPropertyChanged);
			this.cbBoolean.DataBindings.Add(new BoolYesNoBinding("Text", this.bindingPojo, "BoolValue"));

			this.txtPojo.Text = Helper.PrintObj(this.bindingPojo);
		}

		private void BindingPojo_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			this.txtPojo.Text = Helper.PrintObj(this.bindingPojo);
		}

		private void BindingPojoConvertTest_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			this.txtPojo.Text = Helper.PrintObj(this.bindingPojo);
		}

		private void btnRefresh_Click(object sender, EventArgs e)
		{
			this.bindingPojo.Refresh();
		}

	}
}
