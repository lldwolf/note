﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataBindingTest.Model;
using DataBindingTest.Util;

namespace DataBindingTest
{
	public partial class FrmListBinding : Form
	{
		public FrmListBinding()
		{
			InitializeComponent();

			this.PojoList = new List<BindingPojo>();
			this.BindingPojoList = new BindingPojoList();

			for (int i = 0; i < 10; i++)
			{
				BindingPojo pojo1 = new BindingPojo();
				pojo1.ChangeRandomValue();
				this.PojoList.Add(pojo1);

				BindingPojo pojo2 = new BindingPojo();
				pojo2.ChangeRandomValue();
				this.BindingPojoList.Add(pojo2);
			}

			this.dataGridView1.DataSource = this.PojoList;
			this.dataGridView2.DataSource = this.BindingPojoList;
		}

		List<BindingPojo> PojoList;
		BindingPojoList BindingPojoList;

		private void FrmListBinding_Load(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show(this.PojoList.Count.ToString());
		}

		private void button2_Click(object sender, EventArgs e)
		{
			MessageBox.Show(this.BindingPojoList.Count.ToString());
		}

		private void button3_Click(object sender, EventArgs e)
		{
			MessageBox.Show(Helper.PrintObj(this.PojoList[0]));
		}

		private void button4_Click(object sender, EventArgs e)
		{
			MessageBox.Show(Helper.PrintObj(this.BindingPojoList[0]));
		}

		private void button5_Click(object sender, EventArgs e)
		{
			this.BindingPojoList.Clear();
		}
	}
}
