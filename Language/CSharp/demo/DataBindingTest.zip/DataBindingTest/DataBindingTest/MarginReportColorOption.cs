﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;

namespace DataBindingTest
{
	[Serializable]
	internal class MarginReportColorOption : INotifyPropertyChanged, ICloneable
	{
		private string tenor;
		public string Tenor
		{
			get { return this.tenor; }
			set
			{
				this.tenor = value;
				this.NotifyPropertyChanged("Tenor");
			}
		}

		private Color color;
		public Color Color
		{
			get { return this.color; }
			set
			{
				this.color = value;
				this.NotifyPropertyChanged("Color");
			}
		}

		public decimal? TenorValue
		{
			get
			{
				decimal? tenorValue = null;
				
				if (!string.IsNullOrEmpty(this.tenor))
				{
					string[] ss = this.tenor.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
					if (ss.Length > 0)
					{
						tenorValue = decimal.Parse(ss[0]);
					}
				}

				return tenorValue;
			}
		}

		#region INotifyPropertyChanged Members

		private void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion

		#region ICloneable Members

		public object Clone()
		{
			MarginReportColorOption newObj = new MarginReportColorOption();
			newObj.tenor = this.tenor;
			newObj.color = this.color;
			return newObj;
		}

		#endregion
	}
}
