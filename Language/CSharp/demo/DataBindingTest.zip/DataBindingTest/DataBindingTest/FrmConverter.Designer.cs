﻿namespace DataBindingTest
{
	partial class FrmConverter
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtInt = new System.Windows.Forms.TextBox();
			this.cbBoolean = new System.Windows.Forms.ComboBox();
			this.txtRange = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtPojo = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(26, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(19, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Int";
			// 
			// txtInt
			// 
			this.txtInt.Location = new System.Drawing.Point(67, 12);
			this.txtInt.Name = "txtInt";
			this.txtInt.Size = new System.Drawing.Size(174, 20);
			this.txtInt.TabIndex = 3;
			// 
			// cbBoolean
			// 
			this.cbBoolean.FormattingEnabled = true;
			this.cbBoolean.Items.AddRange(new object[] {
            "Yes",
            "No"});
			this.cbBoolean.Location = new System.Drawing.Point(67, 81);
			this.cbBoolean.Name = "cbBoolean";
			this.cbBoolean.Size = new System.Drawing.Size(174, 21);
			this.cbBoolean.TabIndex = 4;
			// 
			// txtRange
			// 
			this.txtRange.Location = new System.Drawing.Point(67, 48);
			this.txtRange.Name = "txtRange";
			this.txtRange.Size = new System.Drawing.Size(174, 20);
			this.txtRange.TabIndex = 6;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(26, 52);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(39, 13);
			this.label2.TabIndex = 5;
			this.label2.Text = "Range";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(26, 85);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(28, 13);
			this.label3.TabIndex = 7;
			this.label3.Text = "Bool";
			// 
			// txtPojo
			// 
			this.txtPojo.Location = new System.Drawing.Point(306, 28);
			this.txtPojo.Multiline = true;
			this.txtPojo.Name = "txtPojo";
			this.txtPojo.Size = new System.Drawing.Size(296, 254);
			this.txtPojo.TabIndex = 8;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(303, 12);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(75, 13);
			this.label4.TabIndex = 9;
			this.label4.Text = "POJO Content";
			// 
			// btnRefresh
			// 
			this.btnRefresh.Location = new System.Drawing.Point(50, 336);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(95, 23);
			this.btnRefresh.TabIndex = 10;
			this.btnRefresh.Text = "Refresh Pojo";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// FrmConverter
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(621, 476);
			this.Controls.Add(this.btnRefresh);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtPojo);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtRange);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbBoolean);
			this.Controls.Add(this.txtInt);
			this.Controls.Add(this.label1);
			this.Name = "FrmConverter";
			this.Text = "FrmBasicBinding";
			this.Load += new System.EventHandler(this.FrmBasicBinding_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtInt;
		private System.Windows.Forms.ComboBox cbBoolean;
		private System.Windows.Forms.TextBox txtRange;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtPojo;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnRefresh;

	}
}