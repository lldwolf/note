﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DataBindingTest.Model;

namespace DataBindingTest
{
	public partial class FrmDevExpressTest : DevExpress.XtraEditors.XtraForm
	{
		public FrmDevExpressTest()
		{
			InitializeComponent();
		}

		private BindingPojo BindingPojo = new BindingPojo();

		private void FrmDevExpressTest_Load(object sender, EventArgs e)
		{
			this.BindingPojo.PropertyChanged += new PropertyChangedEventHandler(BindingPojo_PropertyChanged);
			this.txtStringBinding.DataBindings.Add("Text", this.BindingPojo, "StringValue");
			this.dtDateBinding.DataBindings.Add("DateTime", this.BindingPojo, "DateTimeValue");
			this.chkBoolBinding.DataBindings.Add("Checked", this.BindingPojo, "BoolValue");
			
		}

		private void BindingPojo_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			this.txtPojo.Text = DataBindingTest.Util.Helper.PrintObj(this.BindingPojo);
		}


		private void simpleButton1_Click(object sender, EventArgs e)
		{
			this.txtPojo.Text = DataBindingTest.Util.Helper.PrintObj(this.BindingPojo);
		}

		private void simpleButton2_Click(object sender, EventArgs e)
		{
			this.BindingPojo.ChangeRandomValue();
			this.txtPojo.Text = DataBindingTest.Util.Helper.PrintObj(this.BindingPojo);
		}

		private void simpleButton3_Click(object sender, EventArgs e)
		{
			this.BindingPojo.BoolValue = false;
		}
	}
}