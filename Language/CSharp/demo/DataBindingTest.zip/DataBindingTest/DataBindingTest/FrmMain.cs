﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;
using System.Linq.Expressions;

namespace DataBindingTest
{
	[Serializable]
	public partial class FrmMain : Form
	{
		public FrmMain()
		{
			InitializeComponent();
		}

		private void basicTestToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmBasic frm = new FrmBasic();
			frm.ShowDialog();
		}

		private void devExpressTestToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmDevExpressTest frm = new FrmDevExpressTest();
			frm.ShowDialog();
		}

		private void dataSetTestToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmDataSetBindingTest frm = new FrmDataSetBindingTest();
			frm.ShowDialog();
		}

		private void listBindingToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmListBinding frm = new FrmListBinding();
			frm.ShowDialog();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			//MarginReportOption pojo = new MarginReportOption();
			//PropertyDescriptorCollection props = TypeDescriptor.GetProperties(pojo);
			//PropertyDescriptor prop = props["ShowDealBox"];
			//Expression<Func<MarginReportOption, bool>> exp = a => a.ShowDealBox;
			//bool b = exp.Compile().Invoke(pojo);

			//int count = 100000;

			//Stopwatch sp = new Stopwatch();
			//sp.Start();
			//for (int i = 0; i < count; i++)
			//{
			//    prop.SetValue(pojo, !pojo.ShowDealBox);
			//}
			//sp.Stop();
			//Debug.WriteLine("SetValue used " + sp.ElapsedMilliseconds + "ms");

			//sp.Reset();
			//sp.Start();
			//for (int i = 0; i < count; i++)
			//{
			//    pojo.GetType().InvokeMember("ShowDealBox", BindingFlags.SetProperty, null, pojo, new object[] { !pojo.ShowDealBox });
			//}
			//sp.Stop();
			//Debug.WriteLine("Reflect used " + sp.ElapsedMilliseconds + "ms");

			//sp.Reset();
			//sp.Start();
			//for (int i = 0; i < count; i++)
			//{
			//    pojo.ShowDealBox = !pojo.ShowDealBox;
			//}
			//sp.Stop();
			//Debug.WriteLine("Direct Call used " + sp.ElapsedMilliseconds + "ms");
		}

		private void bindingWithNotifyInterfaceToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmBindingWithoutNofify frm = new FrmBindingWithoutNofify();
			frm.ShowDialog();
		}

		private void converterToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmConverter frm = new FrmConverter();
			frm.ShowDialog();
		}
	}
}
