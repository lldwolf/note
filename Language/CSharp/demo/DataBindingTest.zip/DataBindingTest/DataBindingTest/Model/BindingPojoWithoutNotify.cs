﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataBindingTest.Model
{
	[Serializable]
	public class BindingPojoWithoutNotify
	{
		private static Random r = new Random((int)(DateTime.Now.Ticks));

		public string StringValue { get; set; }

		public BindingPojoWithoutNotify()
		{
			StringValue = System.Guid.NewGuid().ToString();
		}
	}
}
