﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace DataBindingTest.Model
{
	[Serializable]
	public class BindingPojo : INotifyPropertyChanged
	{
		public BindingPojo()
		{
			this.StringValue = "String";
			this.DateTimeValue = new DateTime(1978, 1, 1);
			this.boolValue = true;
		}

		private static Random r = new Random((int)(DateTime.Now.Ticks));

		private DateTime dateTimeValue;
		public DateTime DateTimeValue
		{
			get { return this.dateTimeValue; }
			set
			{
				this.dateTimeValue = value;
				this.NotifyPropertyChanged("DateTimeValue");
			}
		}

		private string stringValue;
		public string StringValue
		{
			get { return this.stringValue; }
			set
			{
				this.stringValue = value;
				this.NotifyPropertyChanged("StringValue");
			}
		}

		private bool boolValue;
		public bool BoolValue
		{
			get { return this.boolValue; }
			set
			{
				this.boolValue = value;
				this.NotifyPropertyChanged("BoolValue");
			}
		}

		public void ChangeRandomValue()
		{
			this.StringValue = System.Guid.NewGuid().ToString();
			this.DateTimeValue = new DateTime(r.Next(1900, 2011), r.Next(1, 12), r.Next(1, 28));
			this.BoolValue = !this.boolValue;
		}


		#region INotifyPropertyChanged Members


		private void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
