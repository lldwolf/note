﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;
using DataBindingTest.Util;

namespace DataBindingTest.Model
{
	public class BindingPojoList : BindingList<BindingPojo>
	{
		public BindingPojoList()
		{
			this.AddingNew += new AddingNewEventHandler(this.BindingPojoList_AddingNew);
		}

		private void BindingPojoList_AddingNew(object sender, AddingNewEventArgs e)
		{
			BindingPojo pojo = new BindingPojo();
			pojo.DateTimeValue = DateTime.Now;
			e.NewObject = pojo;
		}

		protected override void RemoveItem(int index)
		{
			base.RemoveItem(index);
		}

		protected override void ClearItems()
		{
			base.ClearItems();
		}

		protected override void OnListChanged(ListChangedEventArgs e)
		{
			if (e.ListChangedType == ListChangedType.ItemChanged)
			{
				if (e.PropertyDescriptor != null)
				{
					MessageBox.Show(Helper.PrintObj(e.PropertyDescriptor));
				}
				//MessageBox.Show(Helper.PrintObj(e));
			}
			base.OnListChanged(e);
		}

		
	}
}
