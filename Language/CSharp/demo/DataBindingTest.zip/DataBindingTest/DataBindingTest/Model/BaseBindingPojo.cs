﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace DataBindingTest.Model
{
	public class BaseBindingPojo : INotifyPropertyChanged
	{
		#region INotifyPropertyChanged Members

		protected virtual void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
