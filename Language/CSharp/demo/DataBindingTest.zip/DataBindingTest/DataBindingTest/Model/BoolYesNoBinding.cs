﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DataBindingTest.Model
{
	public class BoolYesNoBinding : Binding
	{
		public BoolYesNoBinding(string propertyName, object dataSource, string dataMember)
			: base(propertyName, dataSource, dataMember)
		{
			this.Format += new ConvertEventHandler(this.BoolYesNoBinding_Format);
			this.Parse += new ConvertEventHandler(this.BoolYesNoBinding_Parse);
		}

		private void BoolYesNoBinding_Parse(object sender, ConvertEventArgs e)
		{
			if (e.Value is string)
			{
				e.Value = Convert.ToString(e.Value) == "Yes";
			}
		}

		private void BoolYesNoBinding_Format(object sender, ConvertEventArgs e)
		{
			if (e.Value is bool)
			{
				e.Value = Convert.ToBoolean(e.Value) ? "Yes" : "No";
			}
		}
	}
}
