﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace DataBindingTest.Model
{
	[TypeConverter(typeof(IntRangeTypeConverter))]
	public class IntRange : BaseBindingPojo
	{
		public IntRange()
		{
			this.RefreshValue();
		}

		public IntRange(int minValue, int maxValue)
		{
			this.minValue = minValue;
			this.maxValue = maxValue;
		}

		private Random random = new Random((int)DateTime.Now.Ticks);

		private int minValue;
		public int MinValue
		{
			get { return this.minValue; }
			set
			{
				this.minValue = value;
				this.NotifyPropertyChanged("MinValue");
			}
		}

		private int maxValue;
		public int MaxValue
		{
			get { return this.maxValue; }
			set
			{
				this.maxValue = value;
				this.NotifyPropertyChanged("MaxValue");
			}
		}

		public void RefreshValue()
		{
			this.MinValue = this.random.Next(1, 100);
			this.MaxValue = this.random.Next(100, 200);
		}

		public override string ToString()
		{
			return this.minValue.ToString() + "/" + this.maxValue.ToString();
		}

	}
}
