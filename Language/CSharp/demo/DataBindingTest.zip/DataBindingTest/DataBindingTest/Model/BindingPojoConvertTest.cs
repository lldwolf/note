﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataBindingTest.Model
{
	public class BindingPojoConvertTest : BaseBindingPojo
	{
		private static Random random = new Random((int)(DateTime.Now.Ticks));

		public BindingPojoConvertTest()
		{
			this.intRange = new IntRange();
			this.Refresh();
		}

		private int? intValue;
		public int? IntValue
		{
			get { return this.intValue; }
			set
			{
				this.intValue = value;
				this.NotifyPropertyChanged("IntValue");
			}
		}

		private IntRange intRange;
		public IntRange IntRange
		{
			get { return this.intRange; }
			set
			{
				this.intRange = value;
				this.NotifyPropertyChanged("IntRange");
			}
		}

		private bool boolValue;
		public bool BoolValue
		{
			get { return this.boolValue; }
			set
			{
				this.boolValue = value;
				this.NotifyPropertyChanged("BoolValue");
			}
		}

		public void Refresh()
		{
			this.IntValue = random.Next(1, 1000000);
			this.boolValue = !this.boolValue;
			this.IntRange.RefreshValue();
		}

	}
}
