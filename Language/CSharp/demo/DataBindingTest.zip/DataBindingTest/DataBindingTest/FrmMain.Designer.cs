﻿namespace DataBindingTest
{
	partial class FrmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.bindingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.basicTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.dataSetTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.listBindingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.bindingWithNotifyInterfaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.devExpressTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.converterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(833, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// bindingToolStripMenuItem
			// 
			this.bindingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.basicTestToolStripMenuItem,
            this.dataSetTestToolStripMenuItem,
            this.listBindingToolStripMenuItem,
            this.bindingWithNotifyInterfaceToolStripMenuItem,
            this.devExpressTestToolStripMenuItem,
            this.converterToolStripMenuItem});
			this.bindingToolStripMenuItem.Name = "bindingToolStripMenuItem";
			this.bindingToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
			this.bindingToolStripMenuItem.Text = "Binding";
			// 
			// basicTestToolStripMenuItem
			// 
			this.basicTestToolStripMenuItem.Name = "basicTestToolStripMenuItem";
			this.basicTestToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
			this.basicTestToolStripMenuItem.Text = "Basic Test";
			this.basicTestToolStripMenuItem.Click += new System.EventHandler(this.basicTestToolStripMenuItem_Click);
			// 
			// dataSetTestToolStripMenuItem
			// 
			this.dataSetTestToolStripMenuItem.Name = "dataSetTestToolStripMenuItem";
			this.dataSetTestToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
			this.dataSetTestToolStripMenuItem.Text = "DataSet Test";
			this.dataSetTestToolStripMenuItem.Click += new System.EventHandler(this.dataSetTestToolStripMenuItem_Click);
			// 
			// listBindingToolStripMenuItem
			// 
			this.listBindingToolStripMenuItem.Name = "listBindingToolStripMenuItem";
			this.listBindingToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
			this.listBindingToolStripMenuItem.Text = "List Binding";
			this.listBindingToolStripMenuItem.Click += new System.EventHandler(this.listBindingToolStripMenuItem_Click);
			// 
			// bindingWithNotifyInterfaceToolStripMenuItem
			// 
			this.bindingWithNotifyInterfaceToolStripMenuItem.Name = "bindingWithNotifyInterfaceToolStripMenuItem";
			this.bindingWithNotifyInterfaceToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
			this.bindingWithNotifyInterfaceToolStripMenuItem.Text = "Binding With Notify Interface";
			this.bindingWithNotifyInterfaceToolStripMenuItem.Click += new System.EventHandler(this.bindingWithNotifyInterfaceToolStripMenuItem_Click);
			// 
			// devExpressTestToolStripMenuItem
			// 
			this.devExpressTestToolStripMenuItem.Name = "devExpressTestToolStripMenuItem";
			this.devExpressTestToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
			this.devExpressTestToolStripMenuItem.Text = "DevExpress Test";
			this.devExpressTestToolStripMenuItem.Click += new System.EventHandler(this.devExpressTestToolStripMenuItem_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(371, 347);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(390, 148);
			this.textBox1.TabIndex = 2;
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(379, 281);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 3;
			this.button2.Text = "Test";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// converterToolStripMenuItem
			// 
			this.converterToolStripMenuItem.Name = "converterToolStripMenuItem";
			this.converterToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
			this.converterToolStripMenuItem.Text = "Converter";
			this.converterToolStripMenuItem.Click += new System.EventHandler(this.converterToolStripMenuItem_Click);
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(833, 584);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "FrmMain";
			this.Text = "Form1";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem bindingToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem basicTestToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem devExpressTestToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem dataSetTestToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem listBindingToolStripMenuItem;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ToolStripMenuItem bindingWithNotifyInterfaceToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem converterToolStripMenuItem;
	}
}

