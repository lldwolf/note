﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataBindingTest.Model;
using DataBindingTest.Util;

namespace DataBindingTest
{
	public partial class FrmBindingWithoutNofify : Form
	{
		public FrmBindingWithoutNofify()
		{
			InitializeComponent();

			this.BindingPojo = new BindingPojoWithoutNotify();
			this.textBox1.DataBindings.Add("Text", this.BindingPojo, "StringValue");

			PropertyDescriptorCollection props = TypeDescriptor.GetProperties(this.BindingPojo);
			PropertyDescriptor prop = props["StringValue"];
			prop.AddValueChanged(this.BindingPojo, (sender, e) => this.textBox2.Text = Helper.PrintObj(this.BindingPojo));
		}

		private BindingPojoWithoutNotify BindingPojo;

		private void FrmBindingWithoutNofify_Load(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			PropertyDescriptorCollection props = TypeDescriptor.GetProperties(this.BindingPojo);
			PropertyDescriptor prop = props["StringValue"];
			prop.SetValue(this.BindingPojo, System.Guid.NewGuid().ToString());
		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.textBox2.Text = Helper.PrintObj(this.BindingPojo);
		}
	}
}
