﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using DataBindingTest.Model;
using DataBindingTest.Util;

namespace DataBindingTest
{
	public partial class FrmBasic : Form
	{
		public FrmBasic()
		{
			InitializeComponent();
			this.BindingPojo = new BindingPojo();
		}

		private BindingPojo BindingPojo;

		private void FrmConverter_Load(object sender, EventArgs e)
		{
			this.BindingPojo.PropertyChanged += new PropertyChangedEventHandler(BindingPojo_PropertyChanged);
			this.txtStringBinding.DataBindings.Add("Text", this.BindingPojo, "StringValue");
			this.dtDateBinding.DataBindings.Add("Value", this.BindingPojo, "DateTimeValue");
			this.chkBool.DataBindings.Add("Checked", this.BindingPojo, "BoolValue");
		}

		private void BindingPojo_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			this.txtPojo.Text = Helper.PrintObj(this.BindingPojo);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.txtPojo.Text = Helper.PrintObj(this.BindingPojo);
		}

		private void button1_Click_1(object sender, EventArgs e)
		{
			this.BindingPojo.ChangeRandomValue();
		}

		private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
		{

		}

		private void btnSerialize_Click(object sender, EventArgs e)
		{
			MemoryStream ms = new MemoryStream();
			XmlSerializer formatter = new XmlSerializer(typeof(BindingPojo));
			formatter.Serialize(ms, this.BindingPojo);
			ms.Seek(0, SeekOrigin.Begin);
			StreamReader sr = new StreamReader(ms);
			string str = sr.ReadToEnd();
			this.txtPojo.Text = str;
		}

		private void btnClone_Click(object sender, EventArgs e)
		{
			BindingPojo pojo = CopyHelper.Clone<BindingPojo>(this.BindingPojo);
			this.txtPojo.Text = Helper.PrintObj(pojo);
		}

		private void txtPojo_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
