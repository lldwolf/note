using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NHibernate;
using NHibernate.Cfg;
using log4net;
using log4net.Config;


namespace NGEN
{
	/// <summary>
	/// WebForm1 ��ժҪ˵����
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button Button1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			
		}

		#region Web ������������ɵĴ���
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		static private ILog log = LogManager.GetLogger(typeof(WebForm1));


		private void Button1_Click(object sender, System.EventArgs e)
		{
			Configuration cfg = new Configuration();
			cfg.AddAssembly("ngen");
			
			ISessionFactory factory = cfg.BuildSessionFactory();
			ISession session = factory.OpenSession();
			ITransaction transaction = session.BeginTransaction();

			User newUser = new User();
			newUser.Id = this.TextBox1.Text;
			newUser.UserName = "Joseph Cool";
			newUser.Password = "abc123";
			newUser.EmailAddress = "joe@cool.com";
			newUser.LastLogon = DateTime.Now;

			// Tell NHibernate that this object should be saved
			session.Save(newUser);
 
			// commit all of the changes to the DB and close the ISession
			transaction.Commit();
			session.Close();		

			log.Info("aaaaaaaaaaaaaa");
			
			Response.Write("<script language='jscript'>alert('����ɹ���');</script>");
		}
	}
}
