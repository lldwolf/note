﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataGridViewSort
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}


		/// <summary>
		/// 当前排序列
		/// </summary>
		private int SortedColumnIndex = -1;

		/// <summary>
		/// 是否升序
		/// </summary>
		private bool IsAscending = false;

		/// <summary>
		/// 需按数字格式进行排序的列
		/// </summary>
		private int[] NumberCols = new int[] { 1 };

		private void Form1_Load(object sender, EventArgs e)
		{
			DataTable tb_data = new DataTable();
			tb_data.Columns.Add("说明");
			tb_data.Columns.Add("数字");

			Random r = new Random((int)DateTime.Now.Ticks);
			double sum_val = 0;
			int iVal = 0;
			while(iVal < 10)
			{
				DataRow new_row = tb_data.NewRow();
				new_row[0] = "项" + iVal;
				double val = Convert.ToDouble(Math.Round(r.NextDouble() * 10000, 2));
				if (val > 0 && val < 2000)
				{
					new_row[1] = val.ToString("#,##0.00");
					sum_val += val;
					tb_data.Rows.Add(new_row);
					iVal++;
				}
			}

			DataRow sum_row = tb_data.NewRow();
			sum_row[0] = "合计";
			sum_row[1] = sum_val.ToString("#,##0.00");
			tb_data.Rows.Add(sum_row);

			this.SetDataGridViewSource(this.dataGridView1, tb_data);
			
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.AllowUserToResizeColumns = true;
			this.dataGridView1.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

			for (int iCol = 0; iCol < this.dataGridView1.Columns.Count - 1; iCol++)
				this.dataGridView1.Columns[1].SortMode = DataGridViewColumnSortMode.Programmatic;
		}

		private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			SortOrder order = SortOrder.Ascending;
			if (this.SortedColumnIndex == e.ColumnIndex && this.IsAscending)
				order = SortOrder.Descending;
			this.dataGridView1.Sort(new RowComparer(e.ColumnIndex, order, this.NumberCols));

			for (int iCol = 0; iCol < this.dataGridView1.Columns.Count; iCol++)
				this.dataGridView1.Columns[iCol].HeaderCell.SortGlyphDirection = SortOrder.None;

			this.dataGridView1.Columns[e.ColumnIndex].HeaderCell.SortGlyphDirection = order;

			this.SortedColumnIndex = e.ColumnIndex;
			this.IsAscending = order == SortOrder.Ascending;
		}

		/// <summary>
		/// 将表的内容写入到DataGridView中
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="table"></param>
		private void SetDataGridViewSource(DataGridView grid, DataTable table)
		{
			grid.Columns.Clear();

			for (int iCol = 0; iCol < table.Columns.Count; iCol++)
			{
				DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn();
				col.HeaderText = table.Columns[iCol].ColumnName;
				grid.Columns.Add(col);
			}

			for (int iRow = 0; iRow < table.Rows.Count; iRow++)
			{
				object[] values = new object[table.Columns.Count];
				for (int iCol = 0; iCol < table.Columns.Count; iCol++)
					values[iCol] = table.Rows[iRow][iCol];
				grid.Rows.Add(values);
			}
		}

	}
}