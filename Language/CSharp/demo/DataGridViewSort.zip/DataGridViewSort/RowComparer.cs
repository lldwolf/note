using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

namespace DataGridViewSort
{
	public class RowComparer : IComparer
	{
		private static int ComparedColumnIndex;
		private static int OrderType;
		private int[] num_cols;

		public RowComparer(int column_index, SortOrder sort_order, int[] num_cols)
		{
			this.num_cols = num_cols;
			ComparedColumnIndex = column_index;
			if (sort_order == SortOrder.Descending)
				OrderType = -1;
			else
				OrderType = 1;
		}

		public int Compare(object x, object y)
		{
			DataGridViewRow row1 = x as DataGridViewRow;
			DataGridViewRow row2 = y as DataGridViewRow;
			int title_col = 0;

			if (Convert.ToString(row1.Cells[title_col].Value) == "�ϼ�")
				return 1;

			if (Convert.ToString(row2.Cells[title_col].Value) == "�ϼ�")
				return -1;

			if (row1.Cells[ComparedColumnIndex].Value == DBNull.Value && row2.Cells[ComparedColumnIndex].Value == DBNull.Value)
				return 0;

			if (row1.Cells[ComparedColumnIndex].Value == DBNull.Value)
				return -1 * OrderType;

			if (row2.Cells[ComparedColumnIndex].Value == DBNull.Value)
				return 1 * OrderType;


			List<int> num_col_list = new List<int>();
			foreach (int col_no in this.num_cols)
				num_col_list.Add(col_no);

			int comp_result;
			if (num_col_list.Contains(ComparedColumnIndex))
			{
				double d1 = Convert.ToDouble(row1.Cells[ComparedColumnIndex].Value);
				double d2 = Convert.ToDouble(row2.Cells[ComparedColumnIndex].Value);
				if (d1 > d2)
					comp_result = 1;
				else if (d1 < d2)
					comp_result = -1;
				else
					comp_result = 0;
			}
			else
			{
				comp_result = System.String.Compare(
					Convert.ToString(row1.Cells[ComparedColumnIndex].Value),
					Convert.ToString(row2.Cells[ComparedColumnIndex].Value));
			}

			comp_result *= OrderType;

			return comp_result;
		}
	}
}
