using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using AjaxPro;

namespace AJAXDemo.Examples.HtmlControls
{
	public class Demo
	{
		public Demo()
		{
		}

		[AjaxMethod]
		public string GetSelectedValues(HtmlSelect select)
		{
			string s = "";

			foreach(ListItem item in select.Items)
			{
				if(item.Selected)
					s += "Item " + item.Value + "\r\n";
			}

			return s;
		}

		[AjaxMethod]
		public HtmlSelect GetChildSelect(string car)
		{
			HtmlSelect select = new HtmlSelect();
			select.ID = "car";

			switch(car)
			{
				case "mercedes":
					select.Items.Add("E 300");
					select.Items.Add("E 400");
					select.Items.Add("S Klasse 500");
					select.Items.Add("S Klasse Premium AMG");
					break;

				case "citroen":
					select.Items.Add("C2");
					select.Items.Add("C5");
					select.Items.Add("Berlingo");
					break;

				case "vw":
					select.Items.Add("Polo");
					select.Items.Add("Golf");
					select.Items.Add("Beetle");
					select.Items.Add("Passat");
					break;
			}

			return select;
		}

		[AjaxMethod]
		public HtmlSelect AppendItemOnSelect(HtmlSelect select)
		{
			ListItem last = select.Items[select.Items.Count -1];
			int i = int.Parse(last.Value);

			select.Items.Add(new ListItem("My " + ++i + ". item", i.ToString()));
			
			return select;
		}

	}
}
