using System;
using AjaxPro;

namespace AJAXDemo.Examples.Classes
{
	public class MyClass
	{
		public string FirstName = "";
		public string FamilyName = "";
		public int Age = 0;
	}

	public class MyInheritedClass : MyClass
	{
		public double SizeInMeters = 0.0;
		public Guid ID = Guid.Empty;
	}
}
