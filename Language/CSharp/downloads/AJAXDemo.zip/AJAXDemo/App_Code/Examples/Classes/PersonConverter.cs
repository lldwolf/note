using System;
using System.Text;
using AjaxPro;

namespace AJAXDemo.Examples.Classes
{
	public class PersonConverter : IJavaScriptConverter
	{
		public override string GetClientScript()
		{
			Type t = typeof(Person);

			StringBuilder sb = new StringBuilder();

			sb.Append(@"function Person(id) {
	this.FirstName = """";
	this.FamilyName = """";
	this.Age = 0;
	this.ID = id;
	this.__type = '" + typeof(Person).AssemblyQualifiedName + @"';
}

Person.prototype.get_FullName = function() {
	return this.FirstName + "" "" + this.FamilyName;
}

Person.prototype.toJSON = function() {
	var o = new Object();

	o.firstName = this.FirstName;
	o.familyName = this.FamilyName;
	o.age = this.Age;
	o.id = this.ID;

	return AjaxPro.toJSON(o);
}

Person.prototype.save = function() {
	return Person.save(this);
}

Person.save = function(p) {
	var ps = new PersonSaver();
	return ps.savePerson(p);	// synchronous call
}

var PersonSaver = Class.create();
PersonSaver.prototype = (new AjaxPro.Request()).extend({
	savePerson: function(p) {
		return this.invoke(""SavePerson"", {""p"":p}).value;
	},
	initialize: function() {
		this.url = """ + Utility.HandlerPath + "/" + t.AssemblyQualifiedName + Utility.HandlerExtension + @""";
	}
})

");
			return sb.ToString();
		}

		public override object Deserialize(IJavaScriptObject o, Type t)
		{
			if(!(o is JavaScriptObject))
				throw new NotSupportedException();

			JavaScriptObject ht = (JavaScriptObject)o;

			if(!ht.Contains("id"))
				throw new ArgumentException("Missing argument.", "id");

			Person p = new Person((Guid)JavaScriptDeserializer.Deserialize((IJavaScriptObject)ht["id"], typeof(Guid)));

			if(ht.Contains("firstName"))
				p.FirstName = (string)JavaScriptDeserializer.Deserialize((IJavaScriptObject)ht["firstName"], typeof(string));

			if(ht.Contains("familyName"))
				p.FamilyName = (string)JavaScriptDeserializer.Deserialize((IJavaScriptObject)ht["familyName"], typeof(string));

			if(ht.Contains("age"))
				p.Age = (int)JavaScriptDeserializer.Deserialize((IJavaScriptObject)ht["age"], typeof(int));

			return p;
		}


		public override string Serialize(object o)
		{
			if(!typeof(Person).IsAssignableFrom(o.GetType()))
				throw new NotSupportedException();

			Person p = (Person)o;

			StringBuilder sb = new StringBuilder();

			sb.Append("new Person(");

			sb.Append(JavaScriptSerializer.Serialize(p.ID));
			sb.Append(").extend({FirstName:");
			sb.Append(JavaScriptSerializer.Serialize(p.FirstName));
			sb.Append(",FamilyName:");
			sb.Append(JavaScriptSerializer.Serialize(p.FamilyName));
			sb.Append(",Age:");
			sb.Append(JavaScriptSerializer.Serialize(p.Age));
			sb.Append("})");

			return sb.ToString();
		}


		public override Type[] SerializableTypes
		{
			get
			{
				return new Type[]{typeof(Person)};
			}
		}

		public override Type[] DeserializableTypes
		{
			get
			{
				return new Type[]{typeof(Person)};
			}
		}
	}
}
