using System;
using AjaxPro;

namespace AJAXDemo.Examples.Classes
{
	[JavaScriptConverter(typeof(PersonConverter))]
	public class Person
	{
		private Guid m_ID = Guid.Empty;

		public string FirstName = "";
		public string FamilyName = "";
		public int Age = 0;

		public Person(Guid id)
		{
			m_ID = id;
		}

		public Guid ID
		{
			get
			{
				return m_ID;
			}
		}
		
		[AjaxMethod]
		public static bool SavePerson(Person p)
		{
			return p.Save();
		}

		public bool Save()
		{
			if(this.FirstName != "HANS")
				return true;

			return false;
		}
	}
}
