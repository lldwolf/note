using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using AjaxPro;

namespace AJAXDemo.Examples.Classes
{
	public class Demo
	{
		public Demo()
		{
		}

		[AjaxMethod]
		public MyClass GetMyClass()
		{





			MyClass c = new MyClass();

			c.FirstName = "Michael";
			c.FamilyName = "Schwarz";
			c.Age = 28;

			return c;
		}

		[AjaxMethod]
		public MyInheritedClass GetMyInheritedClass()
		{
			MyInheritedClass c = new MyInheritedClass();

			c.FirstName = "Michael";
			c.FamilyName = "Schwarz";
			c.Age = 28;

			c.SizeInMeters = 1.78;
			c.ID = Guid.NewGuid();

			return c;
		}

		[AjaxMethod]
		public MyClass PutMyClass(MyClass c)
		{
			c.FamilyName = "SERVER-SIDE CHANGE";
			return c;
		}

		[AjaxMethod]
		public Person GetPerson()
		{
			Person p = new Person(new Guid("11111111-1111-1111-1111-111111111111"));

			p.FirstName = "Michael";
			p.FamilyName = "Schwarz";
			p.Age = 28;
	
			return p;
		}
	}
}
