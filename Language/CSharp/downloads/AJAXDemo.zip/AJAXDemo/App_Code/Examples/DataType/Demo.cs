using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using AjaxPro;

namespace AJAXDemo.Examples.DataType
{
	public class Demo
	{
		public Demo()
		{
		}

		[AjaxMethod]
		public bool GetBoolean(bool b)
		{
			return !b;
		}

		[AjaxMethod]
		public int GetInteger(int i)
		{
			return i +10;
		}

		[AjaxMethod]
		public double GetDouble(double d)
		{
			return d + 0.2;
		}

		[AjaxMethod]
		public char GetChar(char c)
		{
			return ++c;
		}

		[AjaxMethod]
		public int GetNumber(int a, int b, double c, float d)
		{
			return (int)((double)a + (double)b + c + d);
		}

		[AjaxMethod]
		public object[] GetNumbers(int[] a, double[] b)
		{
			object[] x = new object[2];
			x[0] = 0;
			x[1] = 0.0;

			foreach(int i in a) x[0] = (int)x[0] + i;
			foreach(double i in b) x[1] = (double)x[1] + i;

			return x;
		}

		[AjaxMethod]
		public DateTime GetDateTime(DateTime d)
		{
			return d.AddHours(4);
		}

		[AjaxMethod]
		public string GetAnyJavaScriptObject(IJavaScriptObject o)
		{
			XmlDocument doc = JavaScriptUtil.ConvertIJavaScriptObjectToXml(o);
			
			return doc.OuterXml;
		}
	}
}
