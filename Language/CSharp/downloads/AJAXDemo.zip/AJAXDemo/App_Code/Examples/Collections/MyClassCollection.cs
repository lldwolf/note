using System;
using System.Collections;
using AJAXDemo.Examples.Classes;

namespace AJAXDemo.Examples.Collections
{
	public class MyClassCollection : CollectionBase  
	{

		public MyClass this[ int index ]  
		{
			get  
			{
				return( (MyClass) List[index] );
			}
			set  
			{
				List[index] = value;
			}
		}

		public int Add( MyClass value )  
		{
			return( List.Add( value ) );
		}

		public int IndexOf( MyClass value )  
		{
			return( List.IndexOf( value ) );
		}

		public void Insert( int index, MyClass value )  
		{
			List.Insert( index, value );
		}

		public void Remove( MyClass value )  
		{
			List.Remove( value );
		}

		public bool Contains( MyClass value )  
		{
			// If value is not of type Int16, this will return false.
			return( List.Contains( value ) );
		}

		protected override void OnInsert( int index, Object value )  
		{
		}

		protected override void OnRemove( int index, Object value )  
		{
		}

		protected override void OnSet( int index, Object oldValue, Object newValue )  
		{
		}

		protected override void OnValidate( Object value )  
		{
		}

	}
}
