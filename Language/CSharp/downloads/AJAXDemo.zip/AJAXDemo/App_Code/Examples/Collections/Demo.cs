using System;
using System.Xml;
using System.Collections;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using AJAXDemo.Examples.Classes;
using AjaxPro;

namespace AJAXDemo.Examples.Collections
{
	public class Demo
	{
		public Demo()
		{
		}

		[AjaxMethod]
		public Int16Collection GetInt16Collection(Int16Collection list)
		{
			if(list == null)
				list = new Int16Collection();

			list.Add(2);
			list.Add(10);
			list.Add(1);

			return list;
		}

		[AjaxMethod]
		public MyClassCollection GetMyClassCollection(MyClassCollection list)
		{
			if(list == null)
				list = new MyClassCollection();

			MyClass c = new MyClass();

			c.FirstName = "Michael";
			c.FamilyName = "Schwarz";
			c.Age = 28;

			list.Add(c);

			c = new MyClass();

			c.FirstName = "Tanja";
			c.FamilyName = "Schwarz";
			c.Age = 25;

			list.Add(c);

			return list;
		}

		[AjaxMethod]
		public Hashtable GetHashtable()
		{
			Hashtable ht = new Hashtable();

			ht.Add("hans", "list");
			ht.Add("will", "list2");
			ht.Add(0, 1);
			ht.Add(true, false);
			ht.Add("date", DateTime.Now);

			return ht;
		}

		[AjaxMethod]
		public NameValueCollection GetNameValueCollection()
		{
			NameValueCollection nc = new NameValueCollection();

			nc.Add("eins", "one");
			nc.Add("zwei", "two");
			nc.Add("drei", "three");

			return nc;
		}

		[AjaxMethod]
		public string GetAnyJavaScriptObject(IJavaScriptObject o)
		{
			XmlDocument doc = JavaScriptUtil.ConvertIJavaScriptObjectToXml(o);
			
			return doc.OuterXml;
		}
	}
}
