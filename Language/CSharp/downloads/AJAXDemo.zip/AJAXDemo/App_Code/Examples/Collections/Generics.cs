using System;
using System.Xml;
using System.Collections;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using AJAXDemo.Examples.Classes;
using AjaxPro;

namespace AJAXDemo.Examples.Collections
{
	public class GenericsDemo
	{
        public GenericsDemo()
		{
		}
	}
}
