using System;
using System.Data;
using AjaxPro;

namespace AJAXDemo.Examples.DataSets
{
	public class Demo
	{
		public Demo()
		{
		}

		/// <summary>
		/// This method will return a DataSet that is saved on the web servers hard disk.
		/// </summary>
		/// <returns>Returns a DataSet.</returns>
		[AjaxMethod]
		public DataSet GetDataSet()
		{
			DataSet ds = new DataSet();

			ds.ReadXml(System.Web.HttpContext.Current.Server.MapPath("~/Examples/DataSets/dataset.xml"), XmlReadMode.ReadSchema);

			return ds;
		}

		/// <summary>
		/// This method will read from the master database on your local SQL server. Please modify 
		/// the connection string if you want to use a different server.
		/// </summary>
		/// <returns>Returns a DataSet.</returns>
		[AjaxMethod]
		public DataSet GetSqlServerTable()
		{
			DataSet ds = new DataSet();
			System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection("server=(local);Trusted_connection=yes;database=master;");
			System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter("SELECT top 5 uid, name, type, refdate FROM sysobjects", conn);

			try
			{
				conn.Open();
			
				try
				{
					da.Fill(ds);
				}
				finally
				{
					conn.Close();
					conn.Dispose();
				}
			}
			catch(Exception)
			{
			}

			return ds;
		}

		/// <summary>
		/// This method will return the XML behind the DataSet. This example will be used to
		/// get a DataSet from the client-side JavaScript.
		/// </summary>
		/// <param name="ds">The DataSet.</param>
		/// <returns>A string representating the XML structure of the DataSet.</returns>
		[AjaxMethod]
		public string GetXmlFromDataSet(DataSet ds)
		{
			return ds.GetXml();
		}
	}
}
