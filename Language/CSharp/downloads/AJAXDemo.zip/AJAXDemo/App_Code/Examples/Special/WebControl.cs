using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Reflection;

namespace AJAXDemo.App_Code.Examples.Special
{
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:WebControl runat=server></{0}:WebControl>")]
	public class WebControl : System.Web.UI.WebControls.TextBox
	{
		public delegate object[] GetDataHandler(string input, int count);

		public GetDataHandler GetDataMethod = null;
		public int Count = 10;

		private string nameOfMethod = "";

		private void Page_Load(object sender, EventArgs e)
		{
			AjaxPro.ClientMethod cm = AjaxPro.ClientMethod.FromDelegate(GetDataMethod);

			if(cm != null)
			{
				AjaxPro.Utility.RegisterTypeForAjax(GetDataMethod.Target.GetType(), this.Page);
				nameOfMethod = cm.ClassName + "," + cm.MethodName;
			}
		}

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();

			if(nameOfMethod != null && nameOfMethod.IndexOf(",") > 0)
			{
				this.Attributes.Add("onkeyup", "ac(this);");

				string script = @"<script type=""text/javascript"">

AjaxPro.getInstance = function(className, o) {
	if(o == null) o = window;
	var c = className.split(""."");	
	if(c.length > 1)
		return AjaxPro.getInstance(className.substr(className.indexOf(""."") +1), o[c[0]]);
	return o[className];
}

var ac = Class.create();

ac.prototype = {
	initialize: function(id, method, count) {
		this.ele = document.getElementById(id);
		this.display = document.getElementById(id + ""_display"");
		addEvent(this.ele, ""keyup"", this.onkeyup.bind(this));
		this.count = count;
		this.timer = null;
		this.className = method.substr(0, method.indexOf("",""));
		this.method = method.substr(method.indexOf("","") +1);
		this.items = [];
		for(var i=0; i<this.count; i++) {
			var d = document.createElement(""div"");
			d.appendChild(document.createTextNode("" ""));
			this.display.appendChild(d);
			this.items.push(d);
		}
	},
	onkeyup: function() {
		if(this.timer != null) clearTimeout(this.timer);
		this.timer = setTimeout(this.getdata.bind(this), 100);
	},
	getdata: function() {
		var c = AjaxPro.getInstance(this.className);
		c[this.method](this.ele.value, this.count, this.ondata.bind(this));
	},
	ondata: function(res) {
		for(var i=0; i<this.count; i++) {
			if(this.items[i].innerText)
				this.items[i].innerText = "" "";
			else
				this.items[i].textContent = "" "";
		}
		for(var i=0; i<res.value.length; i++) {
			if(this.items[i].innerText)
				this.items[i].innerText = res.value[i];
			else
				this.items[i].textContent = res.value[i];
		}
	}
};

</script>";


				Page.RegisterClientScriptBlock("webcontrol", script);
				Page.RegisterStartupScript("webcontrol_" + this.ClientID, "<script type=\"text/javascript\">var x = new ac(\"" + this.ClientID + "\", \"" + nameOfMethod + "\", " + this.Count + ");</script>");
			}
		}

		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit (e);
		}

		protected override void Render(HtmlTextWriter writer)
		{
			base.Render (writer);

			writer.Write("<div id=\"" + this.ClientID + "_display\"></div>");
		}
	}
}
