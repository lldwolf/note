using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Reflection;

namespace AJAXDemo.App_Code.Examples.Special
{
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:AjaxButton runat=server></{0}:AjaxButton>")]
	public class AjaxButton : System.Web.UI.HtmlControls.HtmlButton
	{
		public delegate void OnClickHandler();

		public OnClickHandler OnClick = null;

		private string nameOfMethod = "";

		private void Page_Load(object sender, EventArgs e)
		{
			AjaxPro.ClientMethod cm = AjaxPro.ClientMethod.FromDelegate(OnClick);

			if(cm != null)
			{
				AjaxPro.Utility.RegisterTypeForAjax(OnClick.Target.GetType(), this.Page);
				nameOfMethod = cm.ClassName + "," + cm.MethodName;
			}
		}

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();

			if(nameOfMethod != null && nameOfMethod.IndexOf(",") > 0)
			{
				this.Attributes.Add("onclick", "if(this.callback)" + nameOfMethod.Replace(",", ".") + "(this.callback.bind(this)); else " + nameOfMethod.Replace(",", ".") + "();");
			}
		}

		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit (e);
		}
	}
}
