using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using AjaxPro;

namespace AJAXDemo.Examples.Special
{
	public class Demo : IContextInitializer
	{
		private HttpContext myContext;

		public Demo()
		{
		}

		[AjaxMethod]
		public DateTime GetServerTime()
		{
			return DateTime.Now;
		}

		[AjaxMethod(HttpSessionStateRequirement.ReadWrite)]
		public void SetSession(DateTime value)
		{
			myContext.Session["test"] = value;
		}

		[AjaxMethod(HttpSessionStateRequirement.Read)]
		public DateTime GetSession()
		{
			return (DateTime)myContext.Session["test"];
		}

		[AjaxMethod]
		[AjaxServerCache(10)]
		public DateTime GetCachedServerTime(int i)
		{
			return DateTime.Now;
		}


		#region IContextInitializer Members

		public void InitializeContext(System.Web.HttpContext context)
		{
			myContext = context;
		}

		#endregion
	}
}
