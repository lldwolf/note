
=========================================================================================
=    Thank you for downloading the first and free AJAX library for the Microsoft        =
=    .NET Framework 1.1 and 2.0: Ajax.NET Professional                                  =
=========================================================================================

This starter kit allows you to see where and how you can use Ajax.NET Professional
in your web application. The library will help you to exchange data between the
server and client-side JavaScript and back. There is no real code change on the
server-side .NET code. You simply have to add an attribute to your public methods
you want to use, that's all.

Currently Ajax.NET Professional allows you to use any class or struct you are
already using including DataTable, DataView, Enums, DateTime,... If you want you
can add your own converters if necessary.

=========================================================================================
Files in this ZIP file:

 AjaxProStarterKit.vsi    the web project template for use in Visual Studio .NET 2005
                          simply doubleclick on this file to install the project
                          templates (C# and Visual Basic)

                          This file can be simply renamed to .ZIP to see the content
                          files (can be used with some modifications in .NET 1.1, too.


 AjaxPro.2.dll            the assembly you have to put in you \Bin folder (.NET 2.0)
 AjaxPro.dll              the assembly you have to add as a reference (.NET 1.1)

 web.config               example web.config configuration (.NET 2.0)
                          if you want to use this web.config in .NET 1.1 you have to
                          replace ",AjaxPro.2" by ",AjaxPro"

 changes.txt              latest change history (see http://www.ajaxpro.info/changes.txt)


=========================================================================================
The project templates include following files (Visual Basic and C#):

 default.aspx             a test of several data types as argument and return value
                          example for returning the current time from the web server
                          example of periodical calls using a timer

 feedback.aspx            a common form that will be replaced by Ajax.NET Professional

 security.aspx            test using forms authentication with Ajax.NET Professional

 scripts/example.js       JavaScript code used on default.aspx for the test
 scripts/formfeedback.js  JavaScript code used on feedback.aspx
 scripts/security.js      JavaScript code used on security.aspx


=========================================================================================
For the latest release visit http://www.ajaxpro.info/
Support, questions and feedback at http://groups.google.com/group/ajaxpro/
Latest news and ideas on my blog at http://weblogs.asp.net/mschwarz/

Kind regards,
Michael Schwarz