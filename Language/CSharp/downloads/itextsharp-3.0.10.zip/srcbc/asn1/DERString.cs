using System;

namespace org.bouncycastle.asn1
{
    /**
     * basic interface for DER string objects.
     */
    public interface DERString
    {
        string getString();
    }
}
