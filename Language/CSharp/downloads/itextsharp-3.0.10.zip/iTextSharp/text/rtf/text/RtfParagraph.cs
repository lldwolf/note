using System;
using System.IO;
using System.Collections;
using iTextSharp.text;
using iTextSharp.text.rtf;
using iTextSharp.text.rtf.document;
using iTextSharp.text.rtf.graphic;
/*
 * $Id: RtfParagraph.cs,v 1.2 2005/08/18 23:36:34 psoares33 Exp $
 * $Name:  $
 *
 * Copyright 2001, 2002, 2003, 2004 by Mark Hall
 *
 * The contents of this file are subject to the Mozilla Public License Version 1.1
 * (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the License.
 *
 * The Original Code is 'iText, a free JAVA-PDF library'.
 *
 * The Initial Developer of the Original Code is Bruno Lowagie. Portions created by
 * the Initial Developer are Copyright (C) 1999, 2000, 2001, 2002 by Bruno Lowagie.
 * All Rights Reserved.
 * Co-Developer of the code is Paulo Soares. Portions created by the Co-Developer
 * are Copyright (C) 2000, 2001, 2002 by Paulo Soares. All Rights Reserved.
 *
 * Contributor(s): all the names of the contributors are added in the source code
 * where applicable.
 *
 * Alternatively, the contents of this file may be used under the terms of the
 * LGPL license (the ?GNU LIBRARY GENERAL PUBLIC LICENSE?), in which case the
 * provisions of LGPL are applicable instead of those above.  If you wish to
 * allow use of your version of this file only under the terms of the LGPL
 * License and not to allow others to use your version of this file under
 * the MPL, indicate your decision by deleting the provisions above and
 * replace them with the notice and other provisions required by the LGPL.
 * If you do not delete the provisions above, a recipient may use your version
 * of this file under either the MPL or the GNU LIBRARY GENERAL PUBLIC LICENSE.
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the MPL as stated above or under the terms of the GNU
 * Library General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Library general Public License for more
 * details.
 *
 * If you didn't download this code from the following link, you should check if
 * you aren't using an obsolete version:
 * http://www.lowagie.com/iText/
 */

namespace iTextSharp.text.rtf.text {

    /**
    * The RtfParagraph is an extension of the RtfPhrase that adds alignment and
    * indentation properties. It wraps a Paragraph.
    * 
    * @version $Version:$
    * @author Mark Hall (mhall@edu.uni-klu.ac.at)
    */
    public class RtfParagraph : RtfPhrase {

        /**
        * Constant for the end of a paragraph
        */
        public static byte[] PARAGRAPH = DocWriter.GetISOBytes("\\par");
        /**
        * Constant for left alignment
        */
        public static byte[] ALIGN_LEFT = DocWriter.GetISOBytes("\\ql");
        /**
        * Constant for right alignment
        */
        public static byte[] ALIGN_RIGHT = DocWriter.GetISOBytes("\\qr");
        /**
        * Constant for center alignment
        */
        public static byte[] ALIGN_CENTER = DocWriter.GetISOBytes("\\qc");
        /**
        * Constant for justified alignment
        */
        public static byte[] ALIGN_JUSTIFY = DocWriter.GetISOBytes("\\qj");
        /**
        * Constant for left indentation
        */
        public static byte[] INDENT_LEFT = DocWriter.GetISOBytes("\\li");
        /**
        * Constant for right indentation
        */
        public static byte[] INDENT_RIGHT = DocWriter.GetISOBytes("\\ri");
        /**
        * Constant for keeping the paragraph together on one page
        */
        public static byte[] KEEP_TOGETHER = DocWriter.GetISOBytes("\\keep");
        /**
        * Constant for keeping the paragraph toghether with the next one on one page
        */
        public static byte[] KEEP_TOGETHER_WITH_NEXT = DocWriter.GetISOBytes("\\keepn");
        /**
        * Constant for the space before the paragraph.
        */
        private static byte[] SPACING_BEFORE = DocWriter.GetISOBytes("\\sb");
        /**
        * Constant for the space after the paragraph.
        */
        private static byte[] SPACING_AFTER = DocWriter.GetISOBytes("\\sa");
        
        /**
        * The alignment of this RtfParagraph
        */
        private int alignment = Element.ALIGN_UNDEFINED;
        /**
        * The left indentation of this RtfParagraph
        */
        private int indentLeft = 0;
        /**
        * The right indentation of this RtfParagraph
        */
        private int indentRight = 0;
        /**
        * Whether this RtfParagraph must stay on one page.
        */
        private bool keepTogether = false;
        /**
        * Whether this RtfParagraph must stay on the same page as the next paragraph.
        */
        private bool keepTogetherWithNext = false;
        /**
        * The space before this paragraph.
        */
        private int spacingBefore = 0;
        /**
        * The space after this paragraph.
        */
        private int spacingAfter = 0;
        
        /**
        * Constructs a RtfParagraph belonging to a RtfDocument based on a Paragraph.
        * 
        * @param doc The RtfDocument this RtfParagraph belongs to
        * @param paragraph The Paragraph that this RtfParagraph is based on
        */
        public RtfParagraph(RtfDocument doc, Paragraph paragraph) : base(doc, paragraph) {
            
            this.alignment = paragraph.Alignment;
            this.indentLeft = (int) (paragraph.IndentationLeft * TWIPS_FACTOR);
            this.indentRight = (int) (paragraph.IndentationRight * TWIPS_FACTOR);
            this.keepTogether = paragraph.KeepTogether;
            this.spacingBefore = (int) (paragraph.SpacingBefore * TWIPS_FACTOR);
            this.spacingAfter = (int) (paragraph.SpacingAfter * TWIPS_FACTOR);
            
            for (int i = 0; i < this.chunks.Count; i++) {
                if (chunks[i] is RtfImage) {
                    ((RtfImage) chunks[i]).SetAlignment(this.alignment);
                }
            }
        }
        
        /**
        * Set whether this RtfParagraph must stay on the same page as the next one.
        *  
        * @param keepTogetherWithNext Whether this RtfParagraph must keep together with the next.
        */
        public void SetKeepTogetherWithNext(bool keepTogetherWithNext) {
            this.keepTogetherWithNext = keepTogetherWithNext;
        }
        
        /**
        * Writes the content of this RtfParagraph. First paragraph specific data is written
        * and then the RtfChunks of this RtfParagraph are added.
        * 
        * @return The content of this RtfParagraph
        */
        public override byte[] Write() {
            MemoryStream result = new MemoryStream();
            byte[] t;
            try {
                result.Write(PARAGRAPH_DEFAULTS, 0, PARAGRAPH_DEFAULTS.Length);
                if (this.keepTogether) {
                    result.Write(KEEP_TOGETHER, 0, KEEP_TOGETHER.Length);
                }
                if (this.keepTogetherWithNext) {
                    result.Write(KEEP_TOGETHER_WITH_NEXT, 0, KEEP_TOGETHER_WITH_NEXT.Length);
                }
                if (inTable) {
                    result.Write(IN_TABLE, 0, IN_TABLE.Length);
                }
                switch (alignment) {
                    case Element.ALIGN_LEFT:
                        result.Write(ALIGN_LEFT, 0, ALIGN_LEFT.Length);
                        break;
                    case Element.ALIGN_RIGHT:
                        result.Write(ALIGN_RIGHT, 0, ALIGN_RIGHT.Length);
                        break;
                    case Element.ALIGN_CENTER:
                        result.Write(ALIGN_CENTER, 0, ALIGN_CENTER.Length);
                        break;
                    case Element.ALIGN_JUSTIFIED:
                    case Element.ALIGN_JUSTIFIED_ALL:
                        result.Write(ALIGN_JUSTIFY, 0, ALIGN_JUSTIFY.Length);
                        break;
                }
                result.Write(INDENT_LEFT, 0, INDENT_LEFT.Length);
                result.Write(t = IntToByteArray(indentLeft), 0, t.Length);
                result.Write(INDENT_RIGHT, 0, INDENT_RIGHT.Length);
                result.Write(t = IntToByteArray(indentRight), 0, t.Length);
                if (this.spacingBefore > 0) {
                    result.Write(SPACING_BEFORE, 0, SPACING_BEFORE.Length);
                    result.Write(t = IntToByteArray(this.spacingBefore), 0, t.Length);
                }
                if (this.spacingAfter > 0) {
                    result.Write(SPACING_AFTER, 0, SPACING_AFTER.Length);
                    result.Write(t = IntToByteArray(this.spacingAfter), 0, t.Length);
                }
                if (this.lineLeading > 0) {
                    result.Write(LINE_SPACING, 0, LINE_SPACING.Length);
                    result.Write(t = IntToByteArray(this.lineLeading), 0, t.Length);
                }
                for (int i = 0; i < chunks.Count; i++) {
                    result.Write(t = ((IRtfBasicElement) chunks[i]).Write(), 0, t.Length);
                }
                if (!inTable) {
                    result.Write(PARAGRAPH, 0, PARAGRAPH.Length);
                }
            } catch (IOException) {
            }
            return result.ToArray();
        }

        /**
        * Gets the left indentation of this RtfParagraph.
        * 
        * @return The left indentation.
        */
        public int GetIndentLeft() {
            return this.indentLeft;
        }
        
        /**
        * Sets the left indentation of this RtfParagraph.
        * 
        * @param indentLeft The left indentation to use.
        */
        public void SetIndentLeft(int indentLeft) {
            this.indentLeft = indentLeft;
        }
        
        /**
        * Gets the right indentation of this RtfParagraph.
        * 
        * @return The right indentation.
        */
        public int GetIndentRight()  {
            return this.indentRight;
        }
        
        /**
        * Sets the right indentation of this RtfParagraph.
        * 
        * @param indentRight The right indentation to use.
        */
        public void SetIndentRight(int indentRight) {
            this.indentRight = indentRight;
        }
    }
}