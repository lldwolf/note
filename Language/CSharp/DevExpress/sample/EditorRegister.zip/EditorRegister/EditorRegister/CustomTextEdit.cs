﻿using System;
using System.ComponentModel;

namespace EditorRegister
{
    public class CustomTextEdit : DevExpress.XtraEditors.TextEdit
    {
        internal const string EditorName = "CustomTextEdit";

        #region Register RepositoryItemTextEdit
		static CustomTextEdit()
		{
			RepositoryItemCustomTextEdit.Register();
		}

		public override string EditorTypeName
		{
			get { return EditorName; }
		}
		
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public new RepositoryItemCustomTextEdit Properties
		{
			get
			{
				return base.Properties as RepositoryItemCustomTextEdit;
			}
		}

		#endregion
    }
}
