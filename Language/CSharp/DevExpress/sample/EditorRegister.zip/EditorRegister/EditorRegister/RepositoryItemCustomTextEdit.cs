﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DevExpress.XtraEditors.Registrator;

namespace EditorRegister
{
    public class RepositoryItemCustomTextEdit : DevExpress.XtraEditors.Repository.RepositoryItemTextEdit
    {
        #region Register To IDE
		
		static RepositoryItemCustomTextEdit()
		{
			Register();
		}

		public override string EditorTypeName
		{
            get { return CustomTextEdit.EditorName; }
		}

		public static void Register()
		{
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(
                CustomTextEdit.EditorName,
                typeof(CustomTextEdit),
                typeof(RepositoryItemCustomTextEdit),
                typeof(DevExpress.XtraEditors.ViewInfo.TextEditViewInfo),
                new DevExpress.XtraEditors.Drawing.TextEditPainter(),
                true,
                null));
		}
		#endregion
    }
}
