using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace EditorRegister2
{
    public partial class CtlTest : DevExpress.XtraEditors.XtraUserControl
    {
        public CtlTest()
        {
            InitializeComponent();
        }
    }
}
