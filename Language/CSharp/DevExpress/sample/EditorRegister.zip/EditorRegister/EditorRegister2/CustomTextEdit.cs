﻿using System;
using System.ComponentModel;
using DevExpress.XtraEditors.Registrator;
using EditorRegister2.Registrator;

namespace EditorRegister2
{
    public class CustomTextEdit : DevExpress.XtraEditors.TextEdit
    {
        internal const string EditorName = "CustomTextEdit";

        public override string EditorTypeName
        {
            get { return EditorName; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemCustomTextEdit Properties
        {
            get
            {
                return base.Properties as RepositoryItemCustomTextEdit;
            }
        }

        protected override EditorClassInfo EditorClassInfo
        {
            get
            {
                return CustomEditorRegistrationInfo.Default.Editors[this.EditorTypeName];
            }
        }
    }
}
