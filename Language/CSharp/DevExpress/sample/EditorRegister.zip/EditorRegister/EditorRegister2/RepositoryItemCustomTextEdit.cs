﻿using System;
using DevExpress.XtraEditors.Registrator;
using EditorRegister2.Registrator;

namespace EditorRegister2
{
    public class RepositoryItemCustomTextEdit : DevExpress.XtraEditors.Repository.RepositoryItemTextEdit
    {
        public override string EditorTypeName
        {
            get { return CustomTextEdit.EditorName; }
        }

        protected override EditorClassInfo EditorClassInfo
        {
            get
            {
                return CustomEditorRegistrationInfo.Default.Editors[this.EditorTypeName];
            }
        }
    }
}
