﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DevExpress.XtraEditors.Registrator;

namespace EditorRegister2.Registrator
{
    public class CustomEditorRegistrationInfo
    {
        private static object defaultLocker = new object();
        private static CustomEditorRegistrationInfo fDefault;
        protected EditorClassInfoCollection fEditors = new CustomEditorClassInfoDefaultCollection();

        public static CustomEditorRegistrationInfo Default
        {
            get
            {
                if (fDefault == null)
                {
                    lock (defaultLocker)
                    {
                        if (fDefault == null)
                        {
                            fDefault = new CustomEditorRegistrationInfo();
                        }
                    }
                }
                return fDefault;
            }
        }

        public virtual EditorClassInfoCollection Editors
        {
            get
            {
                return this.fEditors;
            }
        }

    }
}
