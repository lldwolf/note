﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DevExpress.XtraEditors.Registrator;

namespace EditorRegister2.Registrator
{
    public class CustomEditorClassInfoDefaultCollection : EditorClassInfoCollection
    {
        private bool allAdded;
        private static string[] allClasses = new string[] { 
            "CustomTextEdit"
         };
        private readonly Dictionary<string, string> AskedClasses = new Dictionary<string, string>();

        protected override void AddAll()
        {
            if (!this.allAdded)
            {
                foreach (string str in allClasses)
                {
                    this.AddDefEditor(str);
                }
                this.allAdded = true;
            }
        }

        protected override void AddDefEditor(string name)
        {
            if (!this.AskedClasses.ContainsKey(name))
            {
                this.AskedClasses.Add(name, name);
                switch (name)
                {
                    case "CustomTextEdit":
                        this.Add(this.CreateClassInfoCustomTextEdit());
                        return;
                }
            }
        }

        protected virtual EditorClassInfo CreateClassInfoCustomTextEdit()
        {
            return new EditorClassInfo(
                "CustomTextEdit",
                typeof(CustomTextEdit),
                typeof(RepositoryItemCustomTextEdit),
                typeof(DevExpress.XtraEditors.ViewInfo.TextEditViewInfo),
                new DevExpress.XtraEditors.Drawing.TextEditPainter(),
                true,
                null);
        }
    }
}
