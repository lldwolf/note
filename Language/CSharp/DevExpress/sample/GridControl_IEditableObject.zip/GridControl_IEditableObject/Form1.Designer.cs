﻿namespace GridControl_IEditableObject
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gridControl1 = new DevExpress.XtraGrid.GridControl();
			this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
			this.btnNonIEditable = new DevExpress.XtraEditors.SimpleButton();
			this.btnEditable = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// gridControl1
			// 
			this.gridControl1.Location = new System.Drawing.Point(12, 12);
			this.gridControl1.MainView = this.gridView1;
			this.gridControl1.Name = "gridControl1";
			this.gridControl1.Size = new System.Drawing.Size(667, 394);
			this.gridControl1.TabIndex = 0;
			this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
			// 
			// gridView1
			// 
			this.gridView1.GridControl = this.gridControl1;
			this.gridView1.Name = "gridView1";
			// 
			// btnNonIEditable
			// 
			this.btnNonIEditable.Location = new System.Drawing.Point(241, 433);
			this.btnNonIEditable.Name = "btnNonIEditable";
			this.btnNonIEditable.Size = new System.Drawing.Size(83, 23);
			this.btnNonIEditable.TabIndex = 1;
			this.btnNonIEditable.Text = "Non-IEditable";
			this.btnNonIEditable.Click += new System.EventHandler(this.btnNonIEditable_Click);
			// 
			// btnEditable
			// 
			this.btnEditable.Location = new System.Drawing.Point(366, 433);
			this.btnEditable.Name = "btnEditable";
			this.btnEditable.Size = new System.Drawing.Size(83, 23);
			this.btnEditable.TabIndex = 2;
			this.btnEditable.Text = "IEditable";
			this.btnEditable.Click += new System.EventHandler(this.btnEditable_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(691, 480);
			this.Controls.Add(this.btnEditable);
			this.Controls.Add(this.btnNonIEditable);
			this.Controls.Add(this.gridControl1);
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private DevExpress.XtraGrid.GridControl gridControl1;
		private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
		private DevExpress.XtraEditors.SimpleButton btnNonIEditable;
		private DevExpress.XtraEditors.SimpleButton btnEditable;
	}
}