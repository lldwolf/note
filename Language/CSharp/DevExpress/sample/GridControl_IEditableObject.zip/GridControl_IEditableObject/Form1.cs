﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GridControl_IEditableObject
{
	public partial class Form1 : DevExpress.XtraEditors.XtraForm
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btnNonIEditable_Click(object sender, EventArgs e)
		{
			this.gridControl1.DataSource = null;

			BindingList<BasePojo> ds = new BindingList<BasePojo>();
			for (int i = 1; i <= 100; i++)
			{
				BasePojo pojo = new BasePojo();
				pojo.Id = i;
				pojo.Value = "Value " + i;
				ds.Add(pojo);
			}

			this.gridControl1.DataSource = ds;
		}

		private void btnEditable_Click(object sender, EventArgs e)
		{
			this.gridControl1.DataSource = null;

			BindingList<BasePojo> ds = new BindingList<BasePojo>();
			for (int i = 1; i <= 100; i++)
			{
				BasePojo pojo = new EditablePojo();
				pojo.Id = i;
				pojo.Value = "Cancelable Value " + i;
				ds.Add(pojo);
			}

			this.gridControl1.DataSource = ds;
		}
	}
}