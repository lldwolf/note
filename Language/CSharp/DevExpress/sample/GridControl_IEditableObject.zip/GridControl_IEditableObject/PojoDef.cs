﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace GridControl_IEditableObject
{
	public class BasePojo
	{
		public int Id { get; set; }
		public String Value { get; set; }
	}

	public class EditablePojo : BasePojo, IEditableObject
	{

		#region IEditableObject Members

		private EditablePojo cachedPojo;

		public void BeginEdit()
		{
			this.cachedPojo = new EditablePojo();
			this.cachedPojo.Id = this.Id;
			this.cachedPojo.Value = this.Value;
		}

		public void CancelEdit()
		{
			this.Id = this.cachedPojo.Id;
			this.Value = this.cachedPojo.Value;
		}

		public void EndEdit()
		{
			this.cachedPojo.Id = this.Id;
			this.cachedPojo.Value = this.Value;
		}

		#endregion
	}
}
