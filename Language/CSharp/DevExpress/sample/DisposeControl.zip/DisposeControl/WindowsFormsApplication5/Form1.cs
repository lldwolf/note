﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace WindowsFormsApplication5
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			ctrl1 = this.popupContainerControl1;
			ctrl2 = this.popupContainerControl2;
		}

		private int ControlFlag = 0;
		private PopupContainerControl ctrl1, ctrl2;

		private void Form1_Load(object sender, EventArgs e)
		{
			DataTable tb = new DataTable();
			tb.Columns.Add("col1", typeof(string));
			this.gridControl1.DataSource = tb;
		}

		private void simpleButton1_Click(object sender, EventArgs e)
		{
			this.repositoryItemPopupContainerEdit1.PopupControl = (++this.ControlFlag % 2 == 0) ? this.popupContainerControl1 : this.popupContainerControl2;
		}
	}
}
