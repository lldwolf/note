﻿namespace WindowsFormsApplication5
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.popupContainerControl1 = new DevExpress.XtraEditors.PopupContainerControl();
			this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
			this.popupContainerControl2 = new DevExpress.XtraEditors.PopupContainerControl();
			this.dateEdit1 = new DevExpress.XtraEditors.DateEdit();
			this.gridControl1 = new DevExpress.XtraGrid.GridControl();
			this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
			this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
			this.repositoryItemPopupContainerEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
			((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).BeginInit();
			this.popupContainerControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.popupContainerControl2)).BeginInit();
			this.popupContainerControl2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.VistaTimeProperties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit1)).BeginInit();
			this.SuspendLayout();
			// 
			// popupContainerControl1
			// 
			this.popupContainerControl1.Controls.Add(this.checkEdit1);
			this.popupContainerControl1.Location = new System.Drawing.Point(42, 257);
			this.popupContainerControl1.Name = "popupContainerControl1";
			this.popupContainerControl1.Size = new System.Drawing.Size(147, 53);
			this.popupContainerControl1.TabIndex = 1;
			// 
			// checkEdit1
			// 
			this.checkEdit1.Location = new System.Drawing.Point(20, 17);
			this.checkEdit1.Name = "checkEdit1";
			this.checkEdit1.Properties.Caption = "checkEdit1";
			this.checkEdit1.Size = new System.Drawing.Size(75, 19);
			this.checkEdit1.TabIndex = 0;
			// 
			// popupContainerControl2
			// 
			this.popupContainerControl2.Controls.Add(this.dateEdit1);
			this.popupContainerControl2.Location = new System.Drawing.Point(217, 257);
			this.popupContainerControl2.Name = "popupContainerControl2";
			this.popupContainerControl2.Size = new System.Drawing.Size(134, 53);
			this.popupContainerControl2.TabIndex = 2;
			// 
			// dateEdit1
			// 
			this.dateEdit1.EditValue = null;
			this.dateEdit1.Location = new System.Drawing.Point(13, 16);
			this.dateEdit1.Name = "dateEdit1";
			this.dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.dateEdit1.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
			this.dateEdit1.Size = new System.Drawing.Size(100, 20);
			this.dateEdit1.TabIndex = 0;
			// 
			// gridControl1
			// 
			this.gridControl1.Location = new System.Drawing.Point(42, 36);
			this.gridControl1.MainView = this.gridView1;
			this.gridControl1.Name = "gridControl1";
			this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemPopupContainerEdit1});
			this.gridControl1.Size = new System.Drawing.Size(400, 200);
			this.gridControl1.TabIndex = 3;
			this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
			// 
			// gridView1
			// 
			this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1});
			this.gridView1.GridControl = this.gridControl1;
			this.gridView1.Name = "gridView1";
			this.gridView1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
			// 
			// gridColumn1
			// 
			this.gridColumn1.Caption = "Test Column1";
			this.gridColumn1.ColumnEdit = this.repositoryItemPopupContainerEdit1;
			this.gridColumn1.FieldName = "col1";
			this.gridColumn1.Name = "gridColumn1";
			this.gridColumn1.Visible = true;
			this.gridColumn1.VisibleIndex = 0;
			// 
			// simpleButton1
			// 
			this.simpleButton1.Location = new System.Drawing.Point(298, 242);
			this.simpleButton1.Name = "simpleButton1";
			this.simpleButton1.Size = new System.Drawing.Size(126, 23);
			this.simpleButton1.TabIndex = 4;
			this.simpleButton1.Text = "Switch PopupControl";
			this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
			// 
			// repositoryItemPopupContainerEdit1
			// 
			this.repositoryItemPopupContainerEdit1.AutoHeight = false;
			this.repositoryItemPopupContainerEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemPopupContainerEdit1.Name = "repositoryItemPopupContainerEdit1";
			this.repositoryItemPopupContainerEdit1.PopupControl = this.popupContainerControl1;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(488, 361);
			this.Controls.Add(this.simpleButton1);
			this.Controls.Add(this.gridControl1);
			this.Controls.Add(this.popupContainerControl2);
			this.Controls.Add(this.popupContainerControl1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).EndInit();
			this.popupContainerControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.popupContainerControl2)).EndInit();
			this.popupContainerControl2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.VistaTimeProperties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private DevExpress.XtraEditors.PopupContainerControl popupContainerControl1;
		private DevExpress.XtraEditors.CheckEdit checkEdit1;
		private DevExpress.XtraEditors.PopupContainerControl popupContainerControl2;
		private DevExpress.XtraEditors.DateEdit dateEdit1;
		private DevExpress.XtraGrid.GridControl gridControl1;
		private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
		private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
		private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit repositoryItemPopupContainerEdit1;
		private DevExpress.XtraEditors.SimpleButton simpleButton1;
	}
}

