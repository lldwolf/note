﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			DataTable tb = new DataTable();
			tb.Columns.Add("col1", typeof(string));
			tb.Columns.Add("col2", typeof(string));
			tb.Columns.Add("col3", typeof(string));
			this.gridControl1.DataSource = tb;
		}

		DataRow EditingRow;

		private void repositoryItemPopupContainerEdit1_QueryPopUp(object sender, CancelEventArgs e)
		{
			this.EditingRow = null;
			DataRowView rowView = this.gridView1.GetRow(this.gridView1.FocusedRowHandle) as DataRowView;
			if (rowView != null)
				this.EditingRow = rowView.Row;
		}

		private void repositoryItemPopupContainerEdit1_CloseUp(object sender, DevExpress.XtraEditors.Controls.CloseUpEventArgs e)
		{
			string txt1 = this.textEdit1.Text;
			string txt2 = this.textEdit2.Text;

			DataTable tb = this.gridControl1.DataSource as DataTable;
			if (this.EditingRow == null)
			{
				DataRow newRow = tb.NewRow();
				tb.Rows.Add(newRow);
				this.EditingRow = newRow;
                this.gridView1.FocusedRowHandle = this.gridView1.RowCount - 2;
			}

			this.EditingRow["col1"] = txt1 + "-" + txt2;
			e.AcceptValue = true;
			e.Value = txt1 + "-" + txt2;

			//this.gridControl1.RefreshDataSource();
			//this.gridView1.FocusedRowHandle = this.gridView1.RowCount - 1;
		}
	}
}
