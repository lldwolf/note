﻿using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;

namespace WpfApplication1
{
	public class ProgressViewModel : INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		protected void RaisePropertyChanged(string propName)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
			}
		}

		private bool inProcess;
		public bool InProcess
		{
			get { return this.inProcess; }
			set
			{
				if (this.inProcess != value)
				{
					this.inProcess = value;
					RaisePropertyChanged("InProcess");
				}
			}
		}

		private string busyInfo;
		public string BusyInfo
		{
			get { return this.busyInfo; }
			set
			{
				if (this.busyInfo != value)
				{
					this.busyInfo = value;
					RaisePropertyChanged("BusyInfo");
				}
			}
		}

		public void Start()
		{
			this.BusyInfo = "Processing...";
			this.InProcess = true;
			TaskScheduler uiScheduler = TaskScheduler.FromCurrentSynchronizationContext();
			Task task = Task.Factory.StartNew(() => Thread.Sleep(2000));
			task.ContinueWith(t => this.InProcess = false, CancellationToken.None, TaskContinuationOptions.None, uiScheduler);
		}
		
	}
}
