﻿using System.Windows;

namespace WpfApplication1
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			this.DataContext = new ProgressViewModel();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			ProgressViewModel vm = this.DataContext as ProgressViewModel;
			vm.InProcess = true;
			vm.Start();

		}
	}
}
