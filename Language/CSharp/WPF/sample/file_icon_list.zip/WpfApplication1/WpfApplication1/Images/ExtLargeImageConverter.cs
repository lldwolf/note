﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using System.IO;

namespace WpfSkill.Images
{
	public class ExtLargeImageConverter : IValueConverter
	{
		object IValueConverter.Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			return this.GetWpfImage((value as string).ToLower());
		}

		object IValueConverter.ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			throw new NotImplementedException();
		}

		private BitmapImage GetWpfImage(string fileExt)
		{
			System.Drawing.Icon icon = SystemIconReader.GetFileIcon(fileExt, SystemIconReader.IconSize.Large, false);
			System.Drawing.Image image = icon.ToBitmap();

			using (MemoryStream memory = new MemoryStream())
			{
				image.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
				memory.Position = 0;
				BitmapImage bitmapImage = new BitmapImage();
				bitmapImage.BeginInit();
				bitmapImage.StreamSource = memory;
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.EndInit();
				return bitmapImage;
			}
		}

	}
}
