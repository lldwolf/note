﻿using System;
using System.Windows.Data;

namespace WpfSkill.Images
{
	public class ExtFileDescConverter : IValueConverter
	{
		object IValueConverter.Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			return SystemIconReader.GetFileDesc((value as string).ToLower());
		}

		object IValueConverter.ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			throw new NotImplementedException();
		}

	}
}
