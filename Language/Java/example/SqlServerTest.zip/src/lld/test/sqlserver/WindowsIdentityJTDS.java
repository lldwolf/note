package lld.test.sqlserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import net.sourceforge.jtds.jdbc.Driver;



public class WindowsIdentityJTDS
{
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception
	{
		Class.forName("net.sourceforge.jtds.jdbc.Driver");
		DriverManager.registerDriver(new Driver());
		
		Connection connection = DriverManager.getConnection("jdbc:jtds:sqlserver://localhost:1433/pubs;domain=a", "administrator", "liulindong");
		Statement st = connection.createStatement();
		String sql = "select * from authors";
		ResultSet rs = st.executeQuery(sql);
		ResultSetMetaData rs_meta = rs.getMetaData();
		for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
		{
			System.out.print(rs_meta.getColumnName(iCol));
			System.out.print("\t");
		}
		System.out.print("\r\n");
		while(rs.next())
		{
			for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
			{
				System.out.print(rs.getString(iCol));
				System.out.print("\t");
			}
			System.out.print("\r\n");
		}
	}
}
