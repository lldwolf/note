package lld.test.sqlserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import com.microsoft.jdbc.sqlserver.SQLServerDriver;

public class SqlServerIdentity
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception
	{
		Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
		DriverManager.registerDriver(new SQLServerDriver());
		Connection connection = DriverManager.getConnection("jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=pubs", "sa", "sa");
		Statement st = connection.createStatement();
		String sql = "select * from authors";
		ResultSet rs = st.executeQuery(sql);
		ResultSetMetaData rs_meta = rs.getMetaData();
		for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
		{
			System.out.print(rs_meta.getColumnName(iCol));
			System.out.print("\t");
		}
		System.out.print("\r\n");
		while(rs.next())
		{
			for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
			{
				System.out.print(rs.getString(iCol));
				System.out.print("\t");
			}
			System.out.print("\r\n");
		}
	}

}
