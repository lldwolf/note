package lld.test.ajax.struts2json;
import com.opensymphony.xwork2.ActionSupport;


public class JsonTestAction extends ActionSupport
{
	private static final long serialVersionUID = 2949104549856769172L;
	
	private String helloStr;

	public String getHelloStr()
	{
		return helloStr;
	}

	public void setHelloStr(String helloStr)
	{
		this.helloStr = helloStr;
	}
	
	public String execute() throws Exception
	{
		this.setHelloStr("Hello, " + this.helloStr); 
		return SUCCESS;
	}
	
	
}
