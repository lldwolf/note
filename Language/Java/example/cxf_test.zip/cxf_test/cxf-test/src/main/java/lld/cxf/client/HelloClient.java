package lld.cxf.client;

import org.apache.cxf.frontend.ClientProxyFactoryBean;

import lld.cxf.service.HelloService;

public class HelloClient {
	public static void main(String[] args) {
		ClientProxyFactoryBean factory = new ClientProxyFactoryBean();
		factory.setServiceClass(HelloService.class);
		factory.setAddress("http://localhost:9000/Hello");
		HelloService client = (HelloService) factory.create();
		String result = client.sayHi("Lindong");
		System.out.println(result);
	}

}
