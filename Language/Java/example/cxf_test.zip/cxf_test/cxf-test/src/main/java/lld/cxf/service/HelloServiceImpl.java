package lld.cxf.service;

public class HelloServiceImpl implements HelloService {
	public String sayHi(String name) {
		return "Hello " + name;
	}
}