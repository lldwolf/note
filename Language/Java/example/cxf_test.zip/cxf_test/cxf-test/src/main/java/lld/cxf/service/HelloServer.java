package lld.cxf.service;

import org.apache.cxf.frontend.ServerFactoryBean;

public class HelloServer {

	public static void main(String[] args) {
		// Create our service implementation
		HelloService helloWorldImpl = new HelloServiceImpl();
		String defaultUrl = "http://localhost:9000/Hello";
		String url = defaultUrl;
		
		if (args.length > 0) {
			url = args[0];
		}

		// Create our Server
		ServerFactoryBean svrFactory = new ServerFactoryBean();
		svrFactory.setServiceClass(HelloService.class);
		svrFactory.setAddress(url);
		svrFactory.setServiceBean(helloWorldImpl);
		svrFactory.create();
	}

}
