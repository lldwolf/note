package lld.test.jndi;

import java.io.IOException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LookupServlet extends HttpServlet
{
	private static final long serialVersionUID = 6677219828267184673L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			Context jndi_ctx = new InitialContext();
			String key = "jndi_object";
			Object o = jndi_ctx.lookup(key);
			req.setAttribute("found_jndi_obj", o);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher("/lookup_result.jsp");
		dispatcher.forward(req, resp);
	}
	
}
