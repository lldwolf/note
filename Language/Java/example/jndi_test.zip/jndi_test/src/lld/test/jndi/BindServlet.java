package lld.test.jndi;

import java.io.IOException;
import java.util.Date;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class BindServlet extends HttpServlet
{

	private static final long serialVersionUID = 5219969790998794367L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			Context jndi_ctx = new InitialContext();
			String key = "jndi_object";
			jndi_ctx.rebind(key, new Date());
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher("/bind_result.jsp");
		dispatcher.forward(req, resp);
	}
	
}
