package lld.spring_test.hello;

public class HelloImpl implements Hello {
    @Override
    public void sayHi(String name) {
        System.out.println("Hello, " + name);
    }

}
