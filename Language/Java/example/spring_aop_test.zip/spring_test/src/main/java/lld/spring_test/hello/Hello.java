package lld.spring_test.hello;

public interface Hello {
    void sayHi(String name);
}
