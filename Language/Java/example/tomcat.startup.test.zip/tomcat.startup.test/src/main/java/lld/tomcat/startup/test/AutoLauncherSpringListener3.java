package lld.tomcat.startup.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class AutoLauncherSpringListener3 implements ApplicationListener<ContextRefreshedEvent> {
    private static final Logger logger = LogManager.getLogger(AutoLauncherSpringListener3.class);

    public void onApplicationEvent(ContextRefreshedEvent arg0) {
        logger.info("AutoLauncherSpringListener3 is loaded.");
    }

}
