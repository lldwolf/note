package lld.tomcat.startup.test;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AutoLauncherListener1 implements ServletContextListener {
    private static final Logger logger = LogManager.getLogger(AutoLauncherListener1.class);

    public AutoLauncherListener1() {
    }

    public void contextDestroyed(ServletContextEvent arg0) {

    }

    public void contextInitialized(ServletContextEvent arg0) {
        logger.info("AutoLauncherListner1 is loaded.");
    }

}
