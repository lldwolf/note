package lld.tomcat.startup.test;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AutoLauncherServlet1 extends HttpServlet {

    private static final long serialVersionUID = 4031121325445064440L;
    private static final Logger logger = LogManager.getLogger(AutoLauncherServlet1.class);

    public AutoLauncherServlet1() {
    }

    @Override
    public void init() throws ServletException {
        super.init();

        logger.info("AutoLauncherServlet1 is loaded.");
    }

}