package lld.cxf.client.test;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;

import lld.cxf.service.HelloService;
import lld.cxf.service.HelloServicePortType;

public class HelloClientTest {

	private static final QName SERVICE_NAME = new QName("http://service.cxf.lld/", "HelloService");

	public static void main(String[] args) throws MalformedURLException {
		// String wsdlFileName = "HelloService.wsdl";
		// URL wsdlURL = HelloClientTest.class.getClassLoader().getResource(wsdlFileName);

		// String wsdlUrl = "http://localhost:9000/Hello?wsdl";
		String wsdlUrl = "http://162.124.206.60:9000/Hello?wsdl";
		URL wsdlURL = new URL(wsdlUrl);

		HelloService ss = new HelloService(wsdlURL, SERVICE_NAME);
		HelloServicePortType port = ss.getHelloServicePort();
		System.out.println("Invoking sayHi...");
		String result = port.sayHi("Lindong");
		System.out.println("sayHi.result=" + result);

	}

}
