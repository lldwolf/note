package lld.cxf.service;

import javax.jws.WebService;

@WebService
public interface HelloService {
	String sayHi(String name);
}
