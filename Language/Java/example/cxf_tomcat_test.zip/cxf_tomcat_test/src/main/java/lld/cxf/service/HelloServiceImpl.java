package lld.cxf.service;

import org.springframework.stereotype.Component;

@Component("helloService")
public class HelloServiceImpl implements HelloService {
	public String sayHi(String name) {
		return "Hello " + name;
	}
}