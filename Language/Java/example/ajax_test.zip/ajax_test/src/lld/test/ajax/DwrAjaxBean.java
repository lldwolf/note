package lld.test.ajax;

public class DwrAjaxBean
{
	public String sayHello(String uname)
	{
		return "Hello, " + uname;
	}
}
