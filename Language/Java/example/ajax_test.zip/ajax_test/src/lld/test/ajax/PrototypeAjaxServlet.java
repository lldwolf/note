package lld.test.ajax;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PrototypeAjaxServlet extends HttpServlet
{
	private static final long serialVersionUID = -839091745512216332L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String uname = req.getParameter("uname");
		String return_str = "Hello, " + uname;
		resp.getOutputStream().print(return_str);
		resp.getOutputStream().close();
		System.out.println(return_str);
	}
	
	

}
