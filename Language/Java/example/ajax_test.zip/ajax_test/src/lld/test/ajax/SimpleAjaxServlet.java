package lld.test.ajax;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleAjaxServlet extends HttpServlet
{
	private static final long serialVersionUID = -668635463669389981L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String uname = req.getParameter("uname");
		ServletOutputStream os = resp.getOutputStream();
		os.print("Hello, " + uname);
		System.out.println("Hello, AJAX!");
	}
}
