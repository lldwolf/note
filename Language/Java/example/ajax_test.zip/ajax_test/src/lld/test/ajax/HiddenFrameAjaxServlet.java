package lld.test.ajax;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HiddenFrameAjaxServlet extends HttpServlet
{
	private static final long serialVersionUID = -595334169176542957L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String uname = req.getParameter("uname");
		System.out.println("get uname = " + uname);
		String retstr = "Hello, " + uname + ", " + (new Date());
		req.setAttribute("uname", retstr);
		req.getRequestDispatcher("/ajax_callback.jsp").forward(req, resp);
	}
	
	

}
