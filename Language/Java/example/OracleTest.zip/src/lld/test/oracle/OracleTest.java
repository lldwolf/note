package lld.test.oracle;

import java.sql.*;

public class OracleTest
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:intools6", "scott", "tiger");
		Statement st = conn.createStatement();
		String sql = "select * from emp";
		ResultSet rs = st.executeQuery(sql);
		ResultSetMetaData rs_meta = rs.getMetaData();
		for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
		{
			System.out.print(rs_meta.getColumnName(iCol));
			System.out.print("\t");
		}
		System.out.print("\r\n");
		while(rs.next())
		{
			for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
			{
				System.out.print(rs.getString(iCol));
				System.out.print("\t");
			}
			System.out.print("\r\n");
		}


	}

}
