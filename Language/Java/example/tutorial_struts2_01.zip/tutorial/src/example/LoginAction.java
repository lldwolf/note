package example;

import javax.servlet.http.HttpServletRequest;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.ServletRequestAware;

public class LoginAction extends ActionSupport implements ServletRequestAware 
{
	private HttpServletRequest request;
	
    public void setServletRequest(HttpServletRequest request) 
    {
        this.request = request;    
    }
	
	public String execute() throws Exception 
	{
		String user_name = this.request.getParameter("UserName");
		String password = this.request.getParameter("Password");
		if(user_name.equals("lld") && password.equals("lld"))
		{
			return "success";
		}else
			return "failed";
			
    }

}
