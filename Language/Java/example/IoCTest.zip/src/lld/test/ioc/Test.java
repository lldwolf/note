package lld.test.ioc;

public class Test implements ITest
{
	private String name;
	
	@Override
	public String GetString()
	{
		return "Hello " + this.getName();
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

}
