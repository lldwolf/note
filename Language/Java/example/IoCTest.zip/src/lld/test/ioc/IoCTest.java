package lld.test.ioc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class IoCTest
{
	static public void main(String[] args)
	{
		Resource resource = new ClassPathResource("spring-test.xml");
		BeanFactory beans = new XmlBeanFactory(resource);
		ITest itest = (ITest)beans.getBean("test");
		System.out.println(itest.GetString());
	}
}
