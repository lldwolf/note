package lld.test.ioc;

public interface ITest
{
	public String GetString();

}
