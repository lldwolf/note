package lld.test.jndi.rmi;

import java.rmi.registry.LocateRegistry;

import javax.naming.Context;
import javax.naming.InitialContext;

public class Bind
{
	public static void main(String[] args) throws Exception
	{
		LocateRegistry.createRegistry(1099);
		System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.rmi.registry.RegistryContextFactory");
		System.setProperty(Context.PROVIDER_URL, "rmi://localhost:1099");
		InitialContext ctx = new InitialContext();
		String key = "abcef";
		ctx.bind(key, new RemoteDate());
		RemoteDate d = (RemoteDate)ctx.lookup(key);
		System.out.println(d);
		ctx.close(); 
	}

}
