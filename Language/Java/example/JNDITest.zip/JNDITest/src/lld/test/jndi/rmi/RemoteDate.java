package lld.test.jndi.rmi;

import java.rmi.Remote;
import java.util.Date;

public class RemoteDate extends Date implements Remote 
{
	private static final long serialVersionUID = 1L;
}
