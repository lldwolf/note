package lld.test.ireport;

public class AnimalBean
{
	private String animalName;
	private String imagePath;
	public String getAnimalName()
	{
		return animalName;
	}
	public void setAnimalName(String animalName)
	{
		this.animalName = animalName;
	}
	public String getImagePath()
	{
		return imagePath;
	}
	public void setImagePath(String imagePath)
	{
		this.imagePath = imagePath;
	}
}
