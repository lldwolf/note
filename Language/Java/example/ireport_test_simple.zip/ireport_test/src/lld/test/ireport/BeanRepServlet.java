package lld.test.ireport;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporterParameter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsAbstractExporter;
import net.sf.jasperreports.engine.export.JRXlsAbstractExporterParameter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.j2ee.servlets.BaseHttpServlet;
import net.sf.jasperreports.j2ee.servlets.ImageServlet;


public class BeanRepServlet extends HttpServlet
{
	private static final long serialVersionUID = 685516851376141590L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			int report_type = Integer.parseInt(req.getParameter("report_type"));
			
			//���ɲ�������
			ArrayList<ProductBean> data = new ArrayList<ProductBean>();
			for(int i = 1; i <= 99; i++)
			{
				ProductBean bean = new ProductBean();
				bean.setProductName("Product " + i);
				data.add(bean);
			}
			JRDataSource dataSource = new JRBeanCollectionDataSource(data);
			
			String root_path = this.getServletContext().getRealPath("/");
			root_path = root_path.replace('\\', '/');
			String reportFilePath = root_path + "WEB-INF/classes/lld/test/ireport/report_2.jasper";
			System.out.println("jasper file is " + reportFilePath);
			
			if(report_type == 1)
			{
				int print_type = Integer.parseInt(req.getParameter("print_type"));
				if(print_type == 1)
					this.exportPDF(req, resp, reportFilePath, dataSource);
				else
					this.exportPDF3(req, resp, reportFilePath, dataSource);
			}
			else if(report_type == 2)
			{
				this.exportExcel(req, resp, reportFilePath, dataSource);
			}
			else if(report_type == 3)
			{
				this.exportHTML(req, resp, reportFilePath, dataSource);
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	private JasperPrint getJasperPrint(String reportFilePath, JRDataSource dataSource) throws Exception
	{
		File reportFile = new File(reportFilePath);
		if(!reportFile.exists())
			throw new Exception("No file exists - " + reportFilePath);
		
		JasperReport report = (JasperReport)JRLoader.loadObject(reportFile.getPath());
		JasperPrint print = JasperFillManager.fillReport(report, null, dataSource);
		return print;
	}
	
	private void exportPDF(HttpServletRequest req, 
			HttpServletResponse resp, 
			String reportFilePath, 
			JRDataSource dataSource) throws Exception
	{
		System.out.println("export PDF report by JasperPrint...");
		JasperPrint jasperPrint = this.getJasperPrint(reportFilePath, dataSource);

        OutputStream ouputStream = resp.getOutputStream();  
        resp.setContentType("application/pdf");
        resp.setCharacterEncoding("UTF-8");  
        resp.setHeader("Content-Disposition", "attachment; filename=\""  
                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
            	
        // ʹ��JRPdfExproter����������pdf  
        JRPdfExporter exporter = new JRPdfExporter();  
        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);  
        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);  
        exporter.exportReport();
        
        
        ouputStream.close();  
	}

	private void exportPDF3(HttpServletRequest req, 
			HttpServletResponse resp, 
			String reportFilePath, 
			JRDataSource dataSource) throws Exception
	{
		System.out.println("export PDF report by JasperRunManager...");
        OutputStream outputStream = resp.getOutputStream();  
        resp.setContentType("application/pdf");
        resp.setCharacterEncoding("UTF-8");  
        resp.setHeader("Content-Disposition", "attachment; filename=\""  
                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
            	
        byte[] bytes = JasperRunManager.runReportToPdf(reportFilePath, null, dataSource);
        outputStream.write(bytes, 0, bytes.length);
        outputStream.close();  
	}

//	private void exportPDF2(HttpServletRequest req, 
//			HttpServletResponse resp, 
//			String reportFilePath, 
//			JRDataSource dataSource) throws Exception
//	{
//		System.out.println("export PDF report...");
//		JasperPrint jasperPrint = this.getJasperPrint(reportFilePath, dataSource);
//		req.getSession().setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, jasperPrint);  
//        List<?> jasperPrintList = BaseHttpServlet.getJasperPrintList(req);
//		
//
//        // ��û��JasperPrintList�����׳��쳣  
//        if (jasperPrintList == null) {  
//            throw new Exception("��Http Session��û���ҵ�JasperPrint List");  
//        }  
//        OutputStream ouputStream = resp.getOutputStream();  
//        resp.setContentType("application/pdf");
//        resp.setCharacterEncoding("UTF-8");  
//        resp.setHeader("Content-Disposition", "attachment; filename=\""  
//                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
//            	
//        // ʹ��JRPdfExproter����������pdf  
//        JRPdfExporter exporter = new JRPdfExporter();  
//        // ����JasperPrintList  
//        exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrintList);  
//        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);  
//        exporter.exportReport();
//        
//        ouputStream.close();  
//	}

	private void exportExcel(HttpServletRequest req, 
			HttpServletResponse resp, 
			String reportFilePath, 
			JRDataSource dataSource) throws Exception
	{
		System.out.println("export Excel report...");
		JasperPrint jasperPrint = this.getJasperPrint(reportFilePath, dataSource);
        // ��������japserPrint����session�С�   
        req.getSession().setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, jasperPrint);   
        // �õ�japserPrintList   
        List<?> jasperPrintList = BaseHttpServlet.getJasperPrintList(req);   
        // ��û��JasperPrintList�����׳��쳣   
        if (jasperPrintList == null) {   
            throw new Exception("��Http Session��û���ҵ�JasperPrint List");   
        }   
        try {   
            OutputStream ouputStream = resp.getOutputStream();   
            try {   
   
                resp.setContentType("application/xls");   
                resp.setCharacterEncoding("UTF-8");   
                resp.setHeader("Content-Disposition", "attachment; filename=\""   
                        + URLEncoder.encode("Excel����", "UTF-8") + ".xls\"");   
                // Xls��ʽ�ĵ�����
                JRXlsAbstractExporter exporter = new JRXlsExporter();		//poi   
//                JRXlsAbstractExporter exporter = new JExcelApiExporter();		//JExcel
   
                // �ڵ������з���Ҫ������japserPrintList   
                exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrintList);   
   
                exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);   
                // ����Xls������   
                exporter.setParameter(JRXlsAbstractExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);   
                exporter.setParameter(JRXlsAbstractExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE);   
                // ����   
                exporter.exportReport();   
            } catch (JRException e) {   
                e.printStackTrace();   
                throw new Exception("������XLS����ʱ��������!");   
            }   
   
            finally {   
                if (ouputStream != null) {   
                    try {   
                        ouputStream.close();   
                    } catch (IOException ex) {   
                    }   
                }   
            }   
        } catch (IOException ioe) {   
            ioe.printStackTrace();   
            throw new Exception("��Response��ȡ��OutputStreamʱ��������!");   
        }   
	}

	private void exportHTML(HttpServletRequest req, 
			HttpServletResponse resp, 
			String reportFilePath, 
			JRDataSource dataSource) throws Exception
	{
		System.out.println("export HTML report...");
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html;charset=UTF-8");
		JasperPrint jasperPrint = this.getJasperPrint(reportFilePath, dataSource);
		
		JRHtmlExporter exporter = new JRHtmlExporter();
		req.getSession().setAttribute(ImageServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, jasperPrint);  
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);  
		exporter.setParameter(JRExporterParameter.OUTPUT_WRITER, out);  
//		exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "./image?image=");
		exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);    
		exporter.setParameter(JRExporterParameter.CHARACTER_ENCODING, "UTF-8");
		exporter.exportReport();
	}

}
