package lld.test.ireport;

import java.util.ArrayList;

public class ProvinceBean
{
	private String provinceName;
	private ArrayList<CityBean> cities;
	
	public int getCityCount()
	{
		if(this.cities != null)
			return this.cities.size();
		else
			return 0;		
	}
	public String getProvinceName()
	{
		return provinceName;
	}
	public void setProvinceName(String provinceName)
	{
		this.provinceName = provinceName;
	}
	public ArrayList<CityBean> getCities()
	{
		return cities;
	}
	public void setCities(ArrayList<CityBean> cities)
	{
		this.cities = cities;
	}
}
