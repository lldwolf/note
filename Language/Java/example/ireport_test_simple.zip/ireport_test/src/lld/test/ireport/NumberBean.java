package lld.test.ireport;

public class NumberBean
{
	private int number;

	public int getNumber()
	{
		return this.number;
	}

	public void setNumber(int number)
	{
		this.number = number;
	}
}
