package lld.test.ireport;

public class ChartBean
{
	private String language;
	private Double percent;
	public String getLanguage()
	{
		return language;
	}
	public void setLanguage(String language)
	{
		this.language = language;
	}
	public Double getPercent()
	{
		return percent;
	}
	public void setPercent(Double percent)
	{
		this.percent = percent;
	}

}
