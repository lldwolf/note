package lld.test.ireport;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;

public class ChildReportServlet extends HttpServlet
{

	private static final long serialVersionUID = -1233414483047719876L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			String root_path = this.getServletContext().getRealPath("/");
			root_path = root_path.replace('\\', '/');
			String reportFilePath = root_path + "WEB-INF/classes/lld/test/ireport/child_report_jbs_parent.jasper";
			JRDataSource dataSource = this.createDataSource();

			Map<String, String> parameters = new HashMap<String, String>();
			parameters.put("SUBREPORT_DIR", root_path + "WEB-INF/classes/lld/test/ireport/");
			JasperReport report = (JasperReport)JRLoader.loadObject(reportFilePath);
			JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, dataSource);

	        OutputStream ouputStream = resp.getOutputStream();  
	        resp.setContentType("application/pdf");
	        resp.setCharacterEncoding("UTF-8");  
	        resp.setHeader("Content-Disposition", "attachment; filename=\""  
	                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
	            	
	        // ʹ��JRPdfExproter����������pdf  
	        JRPdfExporter exporter = new JRPdfExporter();  
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);  
	        exporter.exportReport();
	        
	        
	        ouputStream.close();  

		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		
	}
	
	private JRDataSource createDataSource()
	{
		//���ɲ�������
		ArrayList<ProvinceBean> provinces = new ArrayList<ProvinceBean>();
		
		ProvinceBean province = new ProvinceBean();
		province.setProvinceName("ɽ��");
		
		ArrayList<CityBean> cities = new ArrayList<CityBean>();
		CityBean city = new CityBean();
		city.setCityName("����");
		cities.add(city);
		city = new CityBean();
		city.setCityName("�ൺ");
		cities.add(city);
		city = new CityBean();
		city.setCityName("Ϋ��");
		cities.add(city);
		
		province.setCities(cities);
		provinces.add(province);

		province = new ProvinceBean();
		province.setProvinceName("����");
		
		cities = new ArrayList<CityBean>();
		city = new CityBean();
		city.setCityName("�Ͼ�");
		cities.add(city);
		city = new CityBean();
		city.setCityName("����");
		cities.add(city);
		city = new CityBean();
		city.setCityName("����");
		cities.add(city);
		
		province.setCities(cities);
		provinces.add(province);

		return new JRBeanCollectionDataSource(provinces);
	}

	public static void main(String[] args) throws Exception
	{
		
	}
}
