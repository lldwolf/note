package lld.test.ireport;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.j2ee.servlets.BaseHttpServlet;

public class BeanReportServlet extends HttpServlet
{
	private static final long serialVersionUID = 348226870594216833L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			//���ɲ�������
			ArrayList<ProductBean> data = new ArrayList<ProductBean>();
			for(int i = 1; i <= 10; i++)
			{
				ProductBean bean = new ProductBean();
				bean.setProductName("Product " + i);
				data.add(bean);
			}
			JRDataSource dataSource = new JRBeanCollectionDataSource(data);
			
			String root_path = this.getServletContext().getRealPath("/");
			root_path = root_path.replace('\\', '/');
			String reportFilePath = root_path + "WEB-INF/classes/lld/test/ireport/report_2.jasper";
			System.out.println("jasper file is " + reportFilePath);
			
			JasperReport report = (JasperReport)JRLoader.loadObject(reportFilePath);
			JasperPrint jasperPrint = JasperFillManager.fillReport(report, null, dataSource);
			req.getSession().setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, jasperPrint);  
	        List<?> jasperPrintList = BaseHttpServlet.getJasperPrintList(req);  

	        // ��û��JasperPrintList�����׳��쳣  
	        if (jasperPrintList == null) {  
	            throw new Exception("��Http Session��û���ҵ�JasperPrint List");  
	        }  
	        OutputStream ouputStream = resp.getOutputStream();  
	        resp.setContentType("application/pdf");
	        resp.setCharacterEncoding("UTF-8");  
	        resp.setHeader("Content-Disposition", "attachment; filename=\""  
	                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
	            	
	        // ʹ��JRPdfExproter����������pdf  
	        JRPdfExporter exporter = new JRPdfExporter();  
	        // ����JasperPrintList  
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrintList);  
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);  
	        exporter.exportReport();
	        
	        ouputStream.close();  
		} catch (Exception e)
		{
			e.printStackTrace();
		}	
	}

}
