package lld.test.ireport;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;

public class ChartReportServlet extends HttpServlet
{
	private static final long serialVersionUID = -7332836030597016040L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			String root_path = this.getServletContext().getRealPath("/");
			root_path = root_path.replace('\\', '/');
			String reportFilePath = root_path + "WEB-INF/classes/lld/test/ireport/chart_rep.jasper";
			JRDataSource dataSource = this.createDataSource();

			JasperReport report = (JasperReport)JRLoader.loadObject(reportFilePath);
			JasperPrint jasperPrint = JasperFillManager.fillReport(report, null, dataSource);

	        OutputStream ouputStream = resp.getOutputStream();  
	        resp.setContentType("application/pdf");
	        resp.setCharacterEncoding("UTF-8");  
	        resp.setHeader("Content-Disposition", "attachment; filename=\""  
	                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
	            	
	        // ʹ��JRPdfExproter����������pdf  
	        JRPdfExporter exporter = new JRPdfExporter();  
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	        
	        exporter.exportReport();
	        
	        
	        ouputStream.close();  

		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		
	}
	
	private JRDataSource createDataSource()
	{
		//���ɲ�������
		ArrayList<ChartBean> beans = new ArrayList<ChartBean>();
		
		ChartBean java_bean = new ChartBean();
		java_bean.setLanguage("Java");
		java_bean.setPercent(0.35);
		beans.add(java_bean);

		ChartBean csharp = new ChartBean();
		csharp.setLanguage(".net");
		csharp.setPercent(0.35);
		beans.add(csharp);
		
		ChartBean php_bean = new ChartBean();
		php_bean.setLanguage("PHP");
		php_bean.setPercent(0.15);
		beans.add(php_bean);
		
		ChartBean other_bean = new ChartBean();
		other_bean.setLanguage("Other");
		other_bean.setPercent(0.15);
		beans.add(other_bean);
		
		return new JRBeanCollectionDataSource(beans);
	}
}
