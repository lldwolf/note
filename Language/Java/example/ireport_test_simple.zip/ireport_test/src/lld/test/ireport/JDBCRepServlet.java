package lld.test.ireport;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sourceforge.jtds.jdbc.Driver;


public class JDBCRepServlet extends HttpServlet
{
	private static final long serialVersionUID = 685516851376141590L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException
	{
		try
		{
			int report_type = Integer.parseInt(req.getParameter("report_type"));
			
			Connection connection = this.getConnection();
			
			String root_path = this.getServletContext().getRealPath("/");
			root_path = root_path.replace('\\', '/');
			String reportFilePath = root_path + "/WEB-INF/classes/lld/test/ireport/report1.jasper";
			System.out.println("jasper file is " + reportFilePath);

			if(report_type == 1)
			{
				int print_type = Integer.parseInt(req.getParameter("print_type"));
				if (print_type == 1)
					this.ExportPDF(req, resp, reportFilePath, connection);
				else if(print_type == 2)
					this.ExportPDF2(req, resp, reportFilePath, connection);
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private Connection getConnection() throws Exception
	{
		Class.forName("net.sourceforge.jtds.jdbc.Driver");
		DriverManager.registerDriver(new Driver());
		Connection connection = DriverManager.getConnection("jdbc:jtds:sqlserver://localhost:1433/NorthWind", "sa", "sa");
		return connection;
	}
	
	public JasperPrint getJasperPrint(String reportFilePath, Connection connection) throws Exception
	{
		File reportFile = new File(reportFilePath);
		if(!reportFile.exists())
			throw new Exception("No file exists - " + reportFilePath);
		
		JasperReport report = (JasperReport)JRLoader.loadObject(reportFile.getPath());
		JasperPrint print = JasperFillManager.fillReport(report, null, connection);
		return print;
	}

	private void ExportPDF(HttpServletRequest req, 
			HttpServletResponse resp, 
			String reportFilePath, 
			Connection connection) throws Exception
	{
		
		System.out.println("export PDF report by JasperPrint...");
		JasperPrint jasperPrint = this.getJasperPrint(reportFilePath, connection);

        OutputStream ouputStream = resp.getOutputStream();  
        resp.setContentType("application/pdf");
        resp.setCharacterEncoding("UTF-8");  
        resp.setHeader("Content-Disposition", "attachment; filename=\""  
                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
            	
        // ʹ��JRPdfExproter����������pdf  
        JRPdfExporter exporter = new JRPdfExporter();  
        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);  
        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);  
        exporter.exportReport();
        
        
        ouputStream.close();  
	}

	private void ExportPDF2(HttpServletRequest req, 
			HttpServletResponse resp, 
			String reportFilePath, 
			Connection connection) throws Exception
	{
		byte[] bytes = JasperRunManager.runReportToPdf(reportFilePath, null, connection);
		resp.setContentType("application/pdf");
		resp.setContentLength(bytes.length);
        resp.setHeader("Content-Disposition", "attachment; filename=\""  
                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
		OutputStream os = resp.getOutputStream();
		os.write(bytes, 0, bytes.length);
		os.flush();
		os.close();
	}

}



