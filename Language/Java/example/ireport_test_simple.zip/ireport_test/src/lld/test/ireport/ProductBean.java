package lld.test.ireport;

public class ProductBean
{
	private String productName;

	public String getProductName()
	{
		return productName;
	}

	public void setProductName(String productName)
	{
		this.productName = productName;
	}
}
