package lld.test.ireport;

public class CityBean
{
	private String cityName;

	public String getCityName()
	{
		return cityName;
	}

	public void setCityName(String cityName)
	{
		this.cityName = cityName;
	}
}
