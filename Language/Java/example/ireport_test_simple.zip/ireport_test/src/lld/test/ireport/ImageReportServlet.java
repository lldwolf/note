package lld.test.ireport;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;

public class ImageReportServlet extends HttpServlet
{
	private static final long serialVersionUID = -5103687616410530065L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			String root_path = this.getServletContext().getRealPath("/");
			root_path = root_path.replace('\\', '/');
			String reportFilePath = root_path + "WEB-INF/classes/lld/test/ireport/image_rep.jasper";
			JRDataSource dataSource = this.createDataSource();

			JasperReport report = (JasperReport)JRLoader.loadObject(reportFilePath);
			JasperPrint jasperPrint = JasperFillManager.fillReport(report, null, dataSource);

	        OutputStream ouputStream = resp.getOutputStream();  
	        resp.setContentType("application/pdf");
	        resp.setCharacterEncoding("UTF-8");  
	        resp.setHeader("Content-Disposition", "attachment; filename=\""  
	                + URLEncoder.encode("PDF����", "UTF-8") + ".pdf\"");  
	            	
	        // ʹ��JRPdfExproter����������pdf  
	        JRPdfExporter exporter = new JRPdfExporter();  
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	        
	        exporter.exportReport();
	        
	        
	        ouputStream.close();  

		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		
	}
	
	private JRDataSource createDataSource()
	{
		//���ɲ�������
		ArrayList<AnimalBean> beans = new ArrayList<AnimalBean>();
		
		String root_path = this.getServletContext().getRealPath("/");
		root_path = root_path.replace('\\', '/');
		root_path = root_path + "image/";
		
		AnimalBean dog_bean = new AnimalBean();
		dog_bean.setAnimalName("doggy");
		dog_bean.setImagePath(root_path + "doggy.jpg");
		beans.add(dog_bean);
		
		AnimalBean mouse_bean = new AnimalBean();
		mouse_bean.setAnimalName("mouse");
		mouse_bean.setImagePath(root_path + "mouse.jpg");
		beans.add(mouse_bean);
		
		return new JRBeanCollectionDataSource(beans);
	}

	public static void main(String[] args) throws Exception
	{
		
	}
}
