package lld.test.odbc;

import java.sql.*;

public class ODBCTest
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
		Connection conn = DriverManager.getConnection("jdbc:odbc:intools_demo", "demo", "demo");
		Statement st = conn.createStatement();
		String sql = "select * from component";
		ResultSet rs = st.executeQuery(sql);
		ResultSetMetaData rs_meta = rs.getMetaData();
		for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
		{
			System.out.print(rs_meta.getColumnName(iCol));
			System.out.print("\t");
		}
		System.out.print("\r\n");
		while(rs.next())
		{
			for(int iCol = 1; iCol <= rs_meta.getColumnCount(); iCol++)
			{
				System.out.print(rs.getString(iCol));
				System.out.print("\t");
			}
			System.out.print("\r\n");
		}

		

	}

}
