package lld.cxf.tomcat.client;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;

import lld.cxf.service.HelloService;
import lld.cxf.service.HelloServiceImplService;

public class TomcatClientTest {

	private static final QName SERVICE_NAME = new QName("http://service.cxf.lld/", "HelloServiceImplService");

	public static void main(String[] args) throws MalformedURLException {
		String wsdlUrl = "http://localhost:8080/HelloServer/services/HelloService?wsdl";
		URL wsdlURL = new URL(wsdlUrl);

		HelloServiceImplService ss = new HelloServiceImplService(wsdlURL, SERVICE_NAME);
		HelloService port = ss.getHelloServiceImplPort();

		System.out.println("Invoking sayHi...");
		String result = port.sayHi("Lindong");
		System.out.println("sayHi.result=" + result);

	}

}
