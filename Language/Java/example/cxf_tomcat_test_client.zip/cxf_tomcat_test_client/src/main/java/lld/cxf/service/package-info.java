@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.cxf.lld/")
package lld.cxf.service;
